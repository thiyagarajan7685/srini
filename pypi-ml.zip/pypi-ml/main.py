import json
import requests
import bs4
import csv


class Search:

    def __init__(self, package) -> None:
        self.name = package
        url = f"https://pypi.org/project/{package}/"
        page_data = requests.get(url=url).text
        self.soup = bs4.BeautifulSoup(page_data, 'html.parser')

    def get_tags(self):
        soup = self.soup.find_all("span", class_="package-keyword")
        keywords = [i.get_text().strip().replace(',', '') for i in soup]
        return list(set(keywords))

    def get_version(self):
        soup = self.soup.find_all("h1", class_="package-header__name")
        keywords = soup[0].get_text().strip().replace(',', '').split()[-1]
        return keywords

    def result(self):
        tags = self.get_tags()
        version = self.get_version()
        return tags, version


def read_lookup():
    f = open('lookup.json', 'r')
    lookup = f.read()
    f.close()
    lookup = json.loads(lookup)
    return lookup


def export_dict_csv(new_dict, fieldnames):
    with open('output.csv', 'w') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(new_dict)


def validate_tags(tags, keywords):
    keywords = keywords.get('keywords')
    status = True if (tags == []) else False
    if keywords and tags:
        for i in keywords:
            if i in tags:
                status = True
                break
    return status


def main():
    ml_package = read_lookup()
    packages = ml_package.get('packages')
    output = []
    for package in packages:
        tags, version = Search(package).result()
        validate = validate_tags(tags, ml_package)
        if validate:
            output.append({"Tags": tags if tags else None,
                          "Package Name": package, "Version": version})
    export_dict_csv(output, ['Package Name', 'Version', 'Tags'])


if __name__ == '__main__':
    main()
