
from app import app, IMG_ALLOWED_EXTENSIONS, PDF_ALLOWED_EXTENSIONS, DOC_ALLOWED_EXTENSIONS
from flask import render_template
from docx import Document
from docx2pdf import convert
from app.utils.sent_cmp_txt import sent_cmp
from app.utils.sent_cmp_txt import ins_del_style,sent_cmp
from app.utils.pdf_extract import html_pdf


def read_docx(file_path):
    doc = Document(file_path)
    content = [paragraph.text for paragraph in doc.paragraphs]
    styles = doc.styles
    return content, styles


def docs_cmp(copy_docx_path, gold_docx_path):

    # Read the content of the documents
    copy_content = read_docx(copy_docx_path)
    gold_content = read_docx(gold_docx_path)

    text1 = gold_content[0]
    text2 = copy_content[0]
    out_pdf = {}
    out_pdf["Page_1"] = [{**sent_cmp(text1, text2), **{"styles": gold_content[1]}}
                        for text1, text2 in zip(text1, text2)]
    
    insert = 0
    delete = 0
    total_words = 0
    page_count = {}
    for page, items in out_pdf.items():
        ins = delt = wrd = 0
        for item in items:
            insert += len(item['insert'])
            delete += len(item['delete'])
            total_words += item['total_words']

            ins += len(item['insert'])
            delt += len(item['delete'])
            wrd += item['total_words']

        page_count[page] = {"insert": ins, "delete": delt, "total_words": wrd}

    total_word_count = {"insert": insert,
                        "delete": delete, "total_words": total_words}
    
    
    docs_html = {page:render_template('difference_docs.html', items=items, ins_del_style=ins_del_style) for page, items in out_pdf.items()}
    # report = docs_html.copy()
    # report["last"] = render_template(
    #     'difference_docs.html', ins_del_style=ins_del_style, page_count=page_count, export=True, total_word_count=total_word_count)
    # # docs_out = html_pdf(docs_html, False)
    # report_out = html_pdf(report, True)

    output_dict = {"html": docs_html,
                   "page_count": page_count, "report": ""}
    output_dict.update(total_word_count)
    
    # # Get the difference between the two documents
    # diff_paragraphs = list(difflib.ndiff(text1, text2))

    # text_html = text_html_pdf(text1, text2)

    # # Combine results
    # output_dict = {
    #     'paragraphs': diff_paragraphs,
    #     'html': text_html
    # }

    return output_dict
