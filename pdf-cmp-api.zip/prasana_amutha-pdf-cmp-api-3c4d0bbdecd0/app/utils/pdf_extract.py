from flask import  render_template
import difflib
import pdfplumber
from app.utils.pdf_table_cmp import extract_pdf_text
from app.utils.sent_cmp_txt import ins_del_style,sent_cmp
from pyhtml2pdf import converter
import os, random, string, base64
from PyPDF2 import PdfMerger
from concurrent.futures import ThreadPoolExecutor


def html_pdf(html_string, opt):
    temp_filename = "".join(random.choices(string.ascii_letters, k = 10))
    temp_path = os.path.abspath("temp")
    all_pdf_path = []

    def threaded_conv(page_no, content):
        html_path = os.path.join(temp_path, f"{temp_filename}_{page_no}.html")
        pdf_path = os.path.join(temp_path, f"{temp_filename}_{page_no}.pdf")
        with open(html_path, "w", encoding="utf-8") as file:
            file.write(content)
        converter.convert(html_path, pdf_path)
        os.remove(html_path)
        return pdf_path
    
    if isinstance(html_string,dict):
        all_page_no = []
        all_content = []
        for page_no, content in html_string.items():
            all_page_no.append(page_no)
            all_content.append(content)
            
        with ThreadPoolExecutor() as executor:
            all_pdf_path = executor.map(threaded_conv, all_page_no, all_content)
        merger = PdfMerger()
        for each_pdf in all_pdf_path:
            merger.append(open(each_pdf, 'rb'))
            os.remove(each_pdf)
        final_pdf_path = os.path.join(temp_path, f"{temp_filename}.pdf")
        with open(final_pdf_path, "wb") as file:
            merger.add_metadata({
                "/Creator":"Regami Solutions",
                "/Producer":""
                })
            merger.write(file)
        encoded_pdf = base64.b64encode(open(final_pdf_path,"rb").read()).decode()
        os.remove(final_pdf_path)
        return encoded_pdf
    
    elif isinstance(html_string, str):
        html_path = os.path.join(temp_path, f"{temp_filename}.html")
        pdf_path = os.path.join(temp_path, f"{temp_filename}.pdf")
        with open(html_path, "w", encoding="utf-8") as file:
            file.write(html_string)
        converter.convert(html_path, pdf_path)
        os.remove(html_path)
        encoded_pdf = base64.b64encode(open(pdf_path,"rb").read()).decode()
        os.remove(pdf_path)
        return encoded_pdf

    # print(html_string,opt)
    return ""


def text_html_pdf(text1, text2):
    html_diff = difflib.HtmlDiff(wrapcolumn=40)
    diff_html = html_diff.make_file(text1, text2)
    encoded_content = html_pdf(diff_html,True)
    return encoded_content

def read_pdf(file_path):
    text = ''
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()

    return text


def pdf_cmp(copy_docx_path, gold_docx_path):

    # Read the content of the documents
    copy_content = read_pdf(copy_docx_path)
    gold_content = read_pdf(gold_docx_path)
    # Get the difference between the two documents
    text1 = gold_content.splitlines()
    text2 = copy_content.splitlines()
    diff_paragraphs = difflib.ndiff(text1, text2)
    text_html = text_html_pdf(text1, text2)

    # Combine results
    output_dict = {
        'paragraphs': list(diff_paragraphs),
        'styles': "",
        "html": text_html
    }

    return output_dict



def pdf_sent_comp(copy_docx_path, gold_docx_path):
    gold_pdf = extract_pdf_text(pdf_path=gold_docx_path)
    cmp_pdf = extract_pdf_text(pdf_path=copy_docx_path)

    out_pdf = {}
    for key in gold_pdf.keys():
        try:
            out_pdf[key] = [{**sent_cmp(text1[0], text2[0]), **{"styles": text2[1]}}
                        for text1, text2 in zip(gold_pdf[key]['page_text'], cmp_pdf[key]['page_text'])]
        except Exception as e:
            print(e)

    insert = 0
    delete = 0
    total_words = 0
    page_count = {}
    for page, items in out_pdf.items():
        ins = delt = wrd = 0
        for item in items:
            insert += len(item['insert'])
            delete += len(item['delete'])
            total_words += item['total_words']

            ins += len(item['insert'])
            delt += len(item['delete'])
            wrd += item['total_words']

        page_count[page] = {"insert": ins, "delete": delt, "total_words": wrd}

    total_word_count = {"insert": insert,
                        "delete": delete, "total_words": total_words}
    
    pdf_html = {page:render_template('difference.html', items=items, ins_del_style=ins_del_style) for page, items in out_pdf.items()}

    report = pdf_html.copy()
    report["last"] = render_template(
        'difference.html', ins_del_style=ins_del_style, page_count=page_count, export=True, total_word_count=total_word_count)


    # pdf_out = html_pdf(pdf_html, False)
    report_out = html_pdf(report, True)
    

    output_dict = {"html": pdf_html,
                   "page_count": page_count, "report": report_out}
    output_dict.update(total_word_count)
    return output_dict

