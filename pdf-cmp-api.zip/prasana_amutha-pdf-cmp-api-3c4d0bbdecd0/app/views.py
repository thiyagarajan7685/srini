from app import app, IMG_ALLOWED_EXTENSIONS, PDF_ALLOWED_EXTENSIONS, DOC_ALLOWED_EXTENSIONS,JSON_ALLOWED_EXTENSIONS
from flask import request, render_template
from app.utils.common.request_response import ok_request, notok_request
from app.utils.common.jwt_token import create_jwt_tokens
import base64
from werkzeug.utils import secure_filename
import os
from app.utils.table_extract import extract_table
import math
from docx2pdf import convert
from app.utils.pdf_extract import pdf_sent_comp
from app.utils.sent_cmp_txt import sent_cmp
from app.utils.docs_extract import docs_cmp
from app.utils.image_extract import img_extract
from app.utils.json_compare import json_comp
from app.utils.common.common_fun import remove_file,save_file_local
import json
import random

@app.template_filter('typeof')
def typeof(obj):
    return type(obj).__name__


@app.template_filter('fontsize')
def font_size(data):
    float_value = None
    for value in data:
        if isinstance(value, float):
            float_value = value
    return math.ceil(float_value) if float_value else 14


@app.template_filter('position')
def position(data):
    position_val = None
    for value in data:
        if isinstance(value, tuple):
            position_val = value
    return position_val if position_val else (90.024, 635.68912, 414.6988, 646.72912)


@app.template_filter('fontname')
def find_boldness(data):
    bold_words = ["normal"]
    family = ["auto"]
    for item in data:
        if isinstance(item, str):
            words = item.split('+')[-1].split('-')
            for word in words:
                if "Bold" in word or "bold" in word:
                    bold_words.append(word)
                else:
                    family.append(word)
    return bold_words[-1].lower(), family[-1].lower()


@app.route("/", methods=["GET"])
def index():
    return "Welcome to POC"

@app.route("/login/user", methods=["POST"])
def get_username():
    obj = {"AB1001": "Prasana", "AB1002": "Kumar"}

    data = request.json
    user_id = data.get("userid")
    password = data.get("password")

    if user_id and (name := obj.get(user_id)) and password:
        access_token = create_jwt_tokens(name)
        return ok_request({"id": user_id, "name": name, "access_token": access_token, "message": "Login Success!"})
    return notok_request({"message": "Invalid user ID"})


@app.route("/text/compare", methods=["POST"])
def get_text_cmp():
    data = request.json
    sentence1 = data.get("gd_txt")
    sentence2 = data.get("cp_txt")
    output = sent_cmp(sentence1, sentence2)


    total_word_count = {"insert": len(output['insert']),
                        "delete": len(output['delete']), "total_words": output['total_words'] if (output['total_words'] != 0) else 1}
    return ok_request({"message": "Success", "output": output,'total_word_count':total_word_count})


def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


@app.route("/docs/compare", methods=["POST"])
def get_docs_cmp():
    gold_docx_path = request.files['gd_file']
    uploaded_files = request.files.getlist('cp_file')

    source_path = save_file_local(gold_docx_path)
    result = {}
    for copy_docx_path in uploaded_files:
        # Save the files to the upload folder
        dest_path = save_file_local(copy_docx_path)
        
        single_output = docs_cmp(dest_path, source_path)
        result[copy_docx_path.filename] = single_output
        remove_file(dest_path)

    src_pth = source_path.replace('docx','pdf')
    convert(source_path,src_pth)
    with open(src_pth, 'rb') as f:
        gold_base64 = base64.b64encode(f.read()).decode('utf-8')

    remove_file(source_path)

    output = {'gold_base64': gold_base64,"result":result}
    return ok_request({"message": "Success", "output": output})


@app.route("/pdf/compare", methods=["POST"])
def get_pdf_cmp():
    gold_docx_path = request.files['gd_file']
    uploaded_files = request.files.getlist('cp_file')
    result = {}
    source_path = save_file_local(gold_docx_path)
    for copy_docx_path in uploaded_files:
        dest_path = save_file_local(copy_docx_path)

        single_output = pdf_sent_comp(dest_path, source_path)
        result[copy_docx_path.filename] = single_output
        remove_file(dest_path)

    with open(source_path, 'rb') as f:
        gold_base64 = base64.b64encode(f.read()).decode('utf-8')

    output = {'gold_base64': gold_base64,"result":result}
    return ok_request({"message": "Success", "output": output})


@app.route("/image/compare", methods=["POST"])
def compare_image():
    if 'gd_file' not in request.files or 'cp_file' not in request.files:
        return notok_request({"message": "Missing files"})

    source = request.files['gd_file']
    uploaded_files = request.files.getlist('cp_file')
    source_path = save_file_local(source)
    output = {}
    for dest in uploaded_files:
        # Save the files to the upload folder
        dest_path = save_file_local(dest)
        data,percentage = img_extract(source_path,dest_path)
        
        # html_output = render_template('image.html', data=data)

        # encoded_pdf = html_pdf(html_output, False)
        output[dest.filename] = {"gd_file": data[0], "cp_file": data[1], "html": "","highlighted":data[2],"percentage":percentage}
        
        remove_file(dest_path)
    remove_file(source_path)
    return ok_request({"message": "Success", "output": output})


@app.route("/table/compare", methods=["POST"])
def compare_table():
    if 'gd_file' not in request.files or 'cp_file' not in request.files:
        return notok_request({"message": "Missing files"})

    source = request.files['gd_file']
    dest = request.files['cp_file']

    # Check if the file types are allowed
    if source and allowed_file(source.filename, PDF_ALLOWED_EXTENSIONS) and dest and allowed_file(dest.filename, PDF_ALLOWED_EXTENSIONS):
        # Save the files to the upload folder
        source_path = save_file_local(source)
        dest_path = save_file_local(dest)
        output = extract_table(source_path, dest_path)

        remove_file(source_path)
        remove_file(dest_path)
        return ok_request({"message": "Success", "output": output})
    return notok_request({"message": "Invalid file types"})


@app.route("/json/compare", methods=["POST"])
def get_json_cmp():
    gold_docx_path = request.files['gd_file']
    uploaded_files = request.files.getlist('cp_file')
    result = {}
    source_path = save_file_local(gold_docx_path)
    gold_json = json.load(open(source_path, "r"))
    for copy_docx_path in uploaded_files:
        dest_path = save_file_local(copy_docx_path)

        single_output =json_comp(source_path,dest_path)
        result[copy_docx_path.filename] = single_output
        remove_file(dest_path)

    remove_file(source_path)
    output = {'gold_json': gold_json,"result":result}
    return ok_request({"message": "Success", "output": output})

@app.route("/dashboard", methods=["GET"])
def dashboard():

    pdf = random.randint(10, 100)
    docx = random.randint(10, 100)
    json = random.randint(10, 100)

    total_compare =  [
    {
        'title': 'Total Words compared',
        'value': random.randint(500, 2000),
        
    },
    {
        'title': 'Total Files Compared',
        'value': pdf+docx+json,
        
    },
    {
        'title': 'Total Images Compared',
        'value': random.randint(10, 100),
        
    }
    ]
    total_files_compare =  [
    {
        'label': 'Total PDF Files compared',
        'value': pdf,
        "id":0
        
    },
    {
        'label': 'Total DOCX Files Compared',
        'value': docx,
        "id":1
        
    },
    {
        'label': 'Total JSON Files Compared',
        'value': json,
        "id":2
        
    }
    ]
    output = {"total_compare":total_compare,"total_files_compare":total_files_compare}
    return ok_request({"message": "Success", "output": output})


