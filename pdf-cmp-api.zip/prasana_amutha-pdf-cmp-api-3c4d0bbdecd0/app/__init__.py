from flask import Flask
from flask_cors import CORS
import os, shutil

app = Flask(__name__)

CORS(app)
UPLOAD_FOLDER = 'uploads'
IMG_ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
PDF_ALLOWED_EXTENSIONS = {'pdf'}
DOC_ALLOWED_EXTENSIONS = {'doc','docx'}
JSON_ALLOWED_EXTENSIONS = {'json'}
TEMP_FOLDER = 'temp'

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

if not os.path.exists(TEMP_FOLDER):
    os.makedirs(TEMP_FOLDER)
else:
    shutil.rmtree(TEMP_FOLDER)
    os.makedirs(TEMP_FOLDER)


app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


from app import views