from app import app, IMG_ALLOWED_EXTENSIONS, PDF_ALLOWED_EXTENSIONS, DOC_ALLOWED_EXTENSIONS
from flask import request, render_template
from app.utils.request_response import ok_request, notok_request
from app.utils.jwt_token import create_jwt_tokens
import difflib
from docx import Document
from skimage.metrics import structural_similarity
import cv2
import numpy as np
import base64
from werkzeug.utils import secure_filename
import os
from app.table_extract import extract_table
import pdfplumber
import pdfkit
from app.pdf_table_cmp import extract_pdf_text
import math
from docx2pdf import convert


@app.template_filter('typeof')
def typeof(obj):
    return type(obj).__name__


@app.template_filter('fontsize')
def font_size(data):
    float_value = None
    for value in data:
        if isinstance(value, float):
            float_value = value
    return math.ceil(float_value) if float_value else 14


@app.template_filter('position')
def position(data):
    position_val = None
    for value in data:
        if isinstance(value, tuple):
            position_val = value
    return position_val if position_val else (90.024, 635.68912, 414.6988, 646.72912)


@app.template_filter('fontname')
def find_boldness(data):
    bold_words = ["normal"]
    family = ["auto"]
    for item in data:
        if isinstance(item, str):
            words = item.split('+')[-1].split('-')
            for word in words:
                if "Bold" in word or "bold" in word:
                    bold_words.append(word)
                else:
                    family.append(word)
    return bold_words[-1].lower(), family[-1].lower()


def ins_del_style(data, insert, delete):
    words = data.split()
    colored_data = []

    for i, word in enumerate(words):
        if i in insert:
            colored_data.append(
                f'<span style="background-color: lightgreen;">{word}</span>')
        elif i in delete:
            colored_data.append(f'<del style="color: red;">{word}</del>')
        else:
            colored_data.append(word)

    colored_sentence = ' '.join(colored_data)

    return colored_sentence


@app.route("/", methods=["GET"])
def index():
    return "Welcome to POC"


def html_pdf(html_string, opt):
    # configuring pdfkit to point to our installation of wkhtmltopdf

    if opt:
        options = {'margin-top': '3cm',
                   'margin-bottom': '3cm',
                   'margin-left': '1.5cm',
                   'margin-right': '1.5cm',
                   'page-size': 'Letter'}
    else:
        options = {
            'page-size': 'Letter',  # Set page size to A4
        }
    # Generate PDF from HTML string
    pdf_bytes = pdfkit.from_string(
        html_string, False, options=options)
    # Encode PDF content as base64
    encoded_pdf = base64.b64encode(pdf_bytes).decode()
    return encoded_pdf


def text_html_pdf(text1, text2):
    html_diff = difflib.HtmlDiff(wrapcolumn=40)
    diff_html = html_diff.make_file(text1, text2)
    encoded_content = html_pdf(diff_html,True)
    return encoded_content


def read_docx(file_path):
    doc = Document(file_path)
    content = [paragraph.text for paragraph in doc.paragraphs]
    styles = doc.styles
    return content, styles


def read_pdf(file_path):
    text = ''
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()

    return text


def sent_cmp(sentence1, sentence2):

    # Get the difference between the two sentences
    differ = difflib.Differ()
    gold_sen = sentence1.split()
    difference = differ.compare(gold_sen, sentence2.split())

    # Initialize empty lists for insertions and deletions
    insertions = []
    deletions = []
    ins_del = ""
    # Process the difference and populate the lists
    index = 0  # Initialize index for tracking the index in sentence1
    for item in difference:
        if item.startswith('+ '):
            insertions.append(index)  # Adding word index in sentence1
        if item.startswith('- '):
            deletions.append(index)  # Adding word index in sentence2
        if not item.startswith('? '):
            ins_del += f"{item[2:] } "
            index += 1

    # Create the output dictionary
    output_dict = {"insert": insertions,
                   "delete": deletions, "ins_del": ins_del, "total_words": len(gold_sen) if (len(gold_sen) not in [0, 1]) and gold_sen[-1] != 't' else 0}

    return output_dict


def docs_cmp(copy_docx_path, gold_docx_path):

    # Read the content of the documents
    copy_content = read_docx(copy_docx_path)
    gold_content = read_docx(gold_docx_path)

    text1 = gold_content[0]
    text2 = copy_content[0]
    out_pdf = {}
    out_pdf["page_1"] = [{**sent_cmp(text1, text2), **{"styles": gold_content[1]}}
                        for text1, text2 in zip(text1, text2)]
    
    insert = 0
    delete = 0
    total_words = 0
    page_count = {}
    for page, items in out_pdf.items():
        ins = delt = wrd = 0
        for item in items:
            insert += len(item['insert'])
            delete += len(item['delete'])
            total_words += item['total_words']

            ins += len(item['insert'])
            delt += len(item['delete'])
            wrd += item['total_words']

        page_count[page] = {"insert": ins, "delete": delt, "total_words": wrd}

    total_word_count = {"insert": insert,
                        "delete": delete, "total_words": total_words}
    docs_html = render_template(
        'difference_docs.html', response=out_pdf, ins_del_style=ins_del_style)
    
    report = render_template(
        'difference_docs.html', response=out_pdf, ins_del_style=ins_del_style, page_count=page_count, export=True, total_word_count=total_word_count)
    

    # docs_out = html_pdf(docs_html, False)
    report_out = html_pdf(report, True)

    output_dict = {"html": docs_html,
                   "page_count": page_count, "report": report_out}
    output_dict.update(total_word_count)
    
    # # Get the difference between the two documents
    # diff_paragraphs = list(difflib.ndiff(text1, text2))

    # text_html = text_html_pdf(text1, text2)

    # # Combine results
    # output_dict = {
    #     'paragraphs': diff_paragraphs,
    #     'html': text_html
    # }

    return output_dict


def pdf_cmp(copy_docx_path, gold_docx_path):

    # Read the content of the documents
    copy_content = read_pdf(copy_docx_path)
    gold_content = read_pdf(gold_docx_path)
    # Get the difference between the two documents
    text1 = gold_content.splitlines()
    text2 = copy_content.splitlines()
    diff_paragraphs = difflib.ndiff(text1, text2)
    text_html = text_html_pdf(text1, text2)

    # Combine results
    output_dict = {
        'paragraphs': list(diff_paragraphs),
        'styles': "",
        "html": text_html
    }

    return output_dict


@app.route("/login/user", methods=["POST"])
def get_username():
    obj = {"AB1001": "Prasana", "AB1002": "Kumar"}

    data = request.json
    user_id = data.get("userid")
    password = data.get("password")

    if user_id and (name := obj.get(user_id)) and password:
        access_token = create_jwt_tokens(name)
        return ok_request({"id": user_id, "name": name, "access_token": access_token, "message": "Login Success!"})
    return notok_request({"message": "Invalid user ID"})


@app.route("/text/compare", methods=["POST"])
def get_text_cmp():
    data = request.json
    sentence1 = data.get("gd_txt")
    sentence2 = data.get("cp_txt")
    output = sent_cmp(sentence1, sentence2)


    total_word_count = {"insert": len(output['insert']),
                        "delete": len(output['delete']), "total_words": output['total_words'] if (output['total_words'] != 0) else 1}
    return ok_request({"message": "Success", "output": output,'total_word_count':total_word_count})


def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


@app.route("/docs/compare", methods=["POST"])
def get_docs_cmp():
    gold_docx_path = request.files['gd_file']
    copy_docx_path = request.files['cp_file']
    if gold_docx_path and allowed_file(gold_docx_path.filename, DOC_ALLOWED_EXTENSIONS) and copy_docx_path and allowed_file(copy_docx_path.filename, DOC_ALLOWED_EXTENSIONS):
        
        source_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(gold_docx_path.filename))
        dest_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(copy_docx_path.filename))

        gold_docx_path.save(source_path)
        copy_docx_path.save(dest_path)


        output = docs_cmp(dest_path, source_path)

        src_pth = source_path.replace('docx','pdf')
        convert(source_path,src_pth)

        with open(src_pth, 'rb') as f:
            gold_base64 = base64.b64encode(f.read()).decode('utf-8')

        try:
            os.remove(src_pth)
        except Exception as e:
            print(e)

        output.update({'gold_base64': gold_base64})
        return ok_request({"message": "Success", "output": output})
    return notok_request({"message": "Invalid file types"})


def pdf_sent_comp(copy_docx_path, gold_docx_path):
    gold_pdf = extract_pdf_text(pdf_path=gold_docx_path)
    cmp_pdf = extract_pdf_text(pdf_path=copy_docx_path)

    out_pdf = {}
    for key in gold_pdf.keys():
        try:
            out_pdf[key] = [{**sent_cmp(text1[0], text2[0]), **{"styles": text2[1]}}
                        for text1, text2 in zip(gold_pdf[key]['page_text'], cmp_pdf[key]['page_text'])]
        except Exception as e:
            print(e)

    insert = 0
    delete = 0
    total_words = 0
    page_count = {}
    for page, items in out_pdf.items():
        ins = delt = wrd = 0
        for item in items:
            insert += len(item['insert'])
            delete += len(item['delete'])
            total_words += item['total_words']

            ins += len(item['insert'])
            delt += len(item['delete'])
            wrd += item['total_words']

        page_count[page] = {"insert": ins, "delete": delt, "total_words": wrd}

    total_word_count = {"insert": insert,
                        "delete": delete, "total_words": total_words}
    pdf_html = render_template(
        'difference.html', response=out_pdf, ins_del_style=ins_del_style)

    report = render_template(
        'difference.html', response=out_pdf, ins_del_style=ins_del_style, page_count=page_count, export=True, total_word_count=total_word_count)

    # pdf_out = html_pdf(pdf_html, False)
    # report_out = html_pdf(report, True)
    

    output_dict = {"html": pdf_html,
                   "page_count": page_count, "report": ""}
    output_dict.update(total_word_count)
    return output_dict


@app.route("/pdf/compare", methods=["POST"])
def get_pdf_cmp():
    gold_docx_path = request.files['gd_file']
    copy_docx_path = request.files['cp_file']

    if gold_docx_path and allowed_file(gold_docx_path.filename, PDF_ALLOWED_EXTENSIONS) and copy_docx_path and allowed_file(copy_docx_path.filename, PDF_ALLOWED_EXTENSIONS):
        source_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(gold_docx_path.filename))
        dest_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(copy_docx_path.filename))

        gold_docx_path.save(source_path)
        copy_docx_path.save(dest_path)

        output = pdf_sent_comp(dest_path, source_path)

        with open(source_path, 'rb') as f:
            gold_base64 = base64.b64encode(f.read()).decode('utf-8')

        try:
            os.remove(source_path)
        except Exception as e:
            print(e)

        output.update({'gold_base64': gold_base64})
        return ok_request({"message": "Success", "output": output})
    return notok_request({"message": "Invalid file types"})


@app.route("/image/compare", methods=["POST"])
def compare_image():
    if 'gd_file' not in request.files or 'cp_file' not in request.files:
        return notok_request({"message": "Missing files"})

    source = request.files['gd_file']
    dest = request.files['cp_file']

    # Check if the file types are allowed
    if source and allowed_file(source.filename, IMG_ALLOWED_EXTENSIONS) and dest and allowed_file(dest.filename, IMG_ALLOWED_EXTENSIONS):
        # Save the files to the upload folder
        source_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(source.filename))
        dest_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(dest.filename))

        source.save(source_path)
        dest.save(dest_path)

        # Load images
        before = cv2.imread(source_path)
        after = cv2.imread(dest_path)

        _, before_encoded = cv2.imencode('.png', before)
        init_before_base64 = base64.b64encode(before_encoded).decode('utf-8')

        _, after_encoded = cv2.imencode('.png', after)
        init_after_base64 = base64.b64encode(after_encoded).decode('utf-8')

        before_height, before_width, _ = before.shape

        after_resized = cv2.resize(after, (before_width, before_height))
        # Convert images to grayscale
        before_gray = cv2.cvtColor(before, cv2.COLOR_BGR2GRAY)
        after_gray = cv2.cvtColor(after_resized, cv2.COLOR_BGR2GRAY)

        # Compute SSIM between the two images
        (score, diff) = structural_similarity(
            before_gray, after_gray, full=True)

        percentage = round(score*100)

        if percentage >= 90:

            # The diff image contains the actual image differences between the two images
            # and is represented as a floating point data type in the range [0,1]
            # so we must convert the array to 8-bit unsigned integers in the range
            # [0,255] before we can use it with OpenCV
            diff = (diff * 255).astype("uint8")
            diff_box = cv2.merge([diff, diff, diff])

            # Threshold the difference image, followed by finding contours to
            # obtain the regions of the two input images that differ
            thresh = cv2.threshold(
                diff, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
            contours = cv2.findContours(
                thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contours = contours[0] if len(contours) == 2 else contours[1]

            mask = np.zeros(before.shape, dtype='uint8')
            filled_after = after.copy()

            for c in contours:
                area = cv2.contourArea(c)
                if area > 40:
                    x, y, w, h = cv2.boundingRect(c)
                    cv2.rectangle(before, (x, y), (x + w, y + h),
                                  (36, 255, 12), 2)
                    cv2.rectangle(after, (x, y), (x + w, y + h),
                                  (36, 255, 12), 2)
                    cv2.rectangle(diff_box, (x, y),
                                  (x + w, y + h), (36, 255, 12), 2)
                    cv2.drawContours(mask, [c], 0, (255, 255, 255), -1)
                    cv2.drawContours(filled_after, [c], 0, (0, 255, 0), -1)

            # Convert images to base64 strings
            _, before_encoded = cv2.imencode('.png', before)
            before_base64 = base64.b64encode(before_encoded).decode('utf-8')

            _, after_encoded = cv2.imencode('.png', after)
            after_base64 = base64.b64encode(after_encoded).decode('utf-8')

            try:
                os.remove(source_path)
                os.remove(dest_path)
            except Exception as e:
                print(e)

            html_output = render_template('image.html', data=[
                                          init_before_base64, init_after_base64, before_base64, after_base64])

            # encoded_pdf = html_pdf(html_output, False)

            return ok_request({"message": "Success", "output": {"gd_file": before_base64, "cp_file": after_base64, "html": ""}})
        return notok_request({"message": "Both Images are different"})
    return notok_request({"message": "Invalid file types"})


@app.route("/table/compare", methods=["POST"])
def compare_table():
    if 'gd_file' not in request.files or 'cp_file' not in request.files:
        return notok_request({"message": "Missing files"})

    source = request.files['gd_file']
    dest = request.files['cp_file']

    # Check if the file types are allowed
    if source and allowed_file(source.filename, PDF_ALLOWED_EXTENSIONS) and dest and allowed_file(dest.filename, PDF_ALLOWED_EXTENSIONS):
        # Save the files to the upload folder
        source_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(source.filename))
        dest_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(dest.filename))

        source.save(source_path)
        dest.save(dest_path)
        output = extract_table(source_path, dest_path)

        try:
            os.remove(source_path)
            os.remove(dest_path)
        except Exception as e:
            print(e)
        return ok_request({"message": "Success", "output": output})
    return notok_request({"message": "Invalid file types"})
