import difflib


def ins_del_style(data, insert, delete):
    words = data.split()
    colored_data = []

    for i, word in enumerate(words):
        if i in insert:
            colored_data.append(
                f'<span style="background-color: lightgreen;">{word}</span>')
        elif i in delete:
            colored_data.append(f'<del style="color: red;">{word}</del>')
        else:
            colored_data.append(word)

    colored_sentence = ' '.join(colored_data)

    return colored_sentence



def sent_cmp(sentence1, sentence2):

    # Get the difference between the two sentences
    differ = difflib.Differ()
    gold_sen = sentence1.split()
    difference = differ.compare(gold_sen, sentence2.split())

    # Initialize empty lists for insertions and deletions
    insertions = []
    deletions = []
    ins_del = ""
    # Process the difference and populate the lists
    index = 0  # Initialize index for tracking the index in sentence1
    for item in difference:
        if item.startswith('+ '):
            insertions.append(index)  # Adding word index in sentence1
        if item.startswith('- '):
            deletions.append(index)  # Adding word index in sentence2
        if not item.startswith('? '):
            ins_del += f"{item[2:] } "
            index += 1

    # Create the output dictionary
    output_dict = {"insert": insertions,
                   "delete": deletions, "ins_del": ins_del, "total_words": len(gold_sen) if (len(gold_sen) not in [0, 1]) and gold_sen[-1] != 't' else 0}

    return output_dict