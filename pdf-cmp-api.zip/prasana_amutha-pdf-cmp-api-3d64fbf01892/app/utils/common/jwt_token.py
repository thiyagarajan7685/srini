from app import app
from flask_jwt_extended import JWTManager, create_access_token

app.config["JWT_SECRET_KEY"] = "fea33c22032c0ff8cd1556fd49e62ab8"
app.config["JWT_TOKEN_LOCATION"] = ["headers", "json"]
jwt = JWTManager(app)

def create_jwt_tokens(var="xxx"):
    access = create_access_token(identity=var)
    return access