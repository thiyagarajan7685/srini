import cv2
import numpy as np
import base64
from skimage.metrics import structural_similarity


def get_image_dimensions(image):
    height, width = image.shape[:2]
    return width, height

def img_extract(source_path,dest_path):

    status = False
    # Load images
    before = cv2.imread(source_path)
    after = cv2.imread(dest_path)

    before_width, before_height = get_image_dimensions(before)
    after_width, after_height = get_image_dimensions(after)

    lowest_width = min(before_width, after_width)
    lowest_height = min(before_height, after_height)

    data = []

    _, before_encoded = cv2.imencode('.png', before)
    init_before_base64 = base64.b64encode(before_encoded).decode('utf-8')

    _, after_encoded = cv2.imencode('.png', after)
    init_after_base64 = base64.b64encode(after_encoded).decode('utf-8')

    resized_after = cv2.resize(after, (lowest_width, lowest_height))
    resized_before = cv2.resize(before, (lowest_width, lowest_height))
    # Convert images to grayscale
    before_gray = cv2.cvtColor(resized_before, cv2.COLOR_BGR2GRAY)
    after_gray = cv2.cvtColor(resized_after, cv2.COLOR_BGR2GRAY)

    # Compute SSIM between the two images
    (score, diff_) = structural_similarity(before_gray, after_gray, full=True)

    percentage = round(score*100)
    if percentage >= 90:
        status = True
                # Compute absolute difference between the two grayscale images
        diff = cv2.absdiff(before_gray, after_gray)

        # Apply thresholding to highlight the differences
        _, thresholded_diff = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)

        # Find contours in the thresholded difference image
        contours, _ = cv2.findContours(thresholded_diff, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Draw bounding boxes around the contours on the before image
        highlighted_before = before.copy()
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(highlighted_before, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Convert images to base64 strings
        _, highlighted_encoded = cv2.imencode('.png', highlighted_before)
        highlighted_base64 = base64.b64encode(highlighted_encoded).decode('utf-8')


        data = [init_before_base64, init_after_base64, highlighted_base64]
    return  status,data
