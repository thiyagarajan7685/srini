import jsondiff
import json


def json_comp(source_path,dest_path):

    source = json.load(open(source_path, "r"))
    dest = json.load(open(dest_path, "r"))
    result = jsondiff.diff(source, dest,syntax="symmetric", marshal=True)
    return {'json_result':result,"gold_json":source}