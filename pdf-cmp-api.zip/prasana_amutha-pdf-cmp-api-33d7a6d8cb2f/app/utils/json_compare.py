import jsondiff
import json
import difflib


def json_comp(source_path,dest_path):

#     source = json.load(open(source_path, "r"))
#     dest = json.load(open(dest_path, "r"))
#     result = jsondiff.diff(source, dest,syntax="symmetric", marshal=True)
#     return {'json_result':result,"gold_json":source}

    source = json.load(open(source_path, "r"))
    dest = json.load(open(dest_path, "r"))
    
    d = difflib.Differ()
    diff = list(d.compare(json.dumps(source,sort_keys=True, indent=2).splitlines(),
                            json.dumps(dest,sort_keys=True, indent=2).splitlines()))
    
    html_content = """<html><head><style>
    .inserted {background-color: #aaffaa;}
    .deleted {background-color: #ffaaaa;}
    </style></head><body><pre>"""
    for line in diff:
        if line.startswith('+ '):
            line=line.replace("+", " ", 1)
            html_content += f'<span class="inserted">{line}</span>\n'
        elif line.startswith('- '):
            line = line.replace("-", " ", 1)
            html_content += f'<span class="deleted">{line}</span>\n'
        elif line.startswith('? '):
            pass
        else:
            html_content += f'{line}\n'

    html_content += '</pre></body></html>'
    return {'json_result':html_content,"gold_json":source}
