import pdfplumber
import pandas as pd
import numpy as np
import json

def extract_tables_pdf(file_path):
    all_tables = []
    with pdfplumber.open(file_path) as pdf:
        # Iterate through pages
        pages = []
        for i, page in enumerate(pdf.pages):
            # Extract tables from the page
            page_table = []
            tables = page.extract_tables()
            # Iterate through the tables and append them to the list
            for j, table in enumerate(tables):
                df = pd.DataFrame(table)
                df = df.rename(columns=df.iloc[0]).drop(df.index[0]).reset_index(drop=True)
                page_table.append(df)
            pages.append(page_table)
        all_tables = pages
    return all_tables


def extract_table(source,destination):
    diff_val = diff  = diffval_columns = diff_columns = []
    # Extract tables from source and destination PDFs
    source_tables = extract_tables_pdf(source)
    destination_tables = extract_tables_pdf(destination)
    
    if len(source_tables) < len(destination_tables):
        smaller_length = len(source_tables)
    else:
        smaller_length = len(destination_tables)
    
    for i in range(smaller_length):
        # Access elements from both arrays using the loop index
        source_table = source_tables[i]
        destination_table = destination_tables[i]

        if len(source_table) < len(destination_table):
            smaller_len = len(source_table)
        else:
            smaller_len = len(destination_table)

        for j in range(smaller_len):
            # Access elements from both arrays using the loop index
            df_a = source_table[j]
            df_b = destination_table[j]

            missing_columns = df_a.columns.difference(df_b.columns)

            # Add missing columns to df_b and fill with NaN
            for column in missing_columns:
                df_b[column] = np.nan
            df_b = df_b[df_a.columns]

            # Check if the dataframes exist in the dictionary
            if df_a is not None and df_b is not None:
                # Perform dataframe comparison
                comparison_result = df_a.equals(df_b)

                # Highlight the differences if dataframes are different
                if not comparison_result:

                    # Apply the highlight function to the dataframe
                    diff_val = df_a.compare(df_b,keep_equal=True, keep_shape = True,result_names=('source', 'destination'))
                    diff = df_a.compare(df_b,keep_equal=False, keep_shape = True,result_names=('source', 'destination'))

                    diff_columns = list(diff.columns)
                    diffval_columns = list(diff_val.columns)
                    diff_val = json.loads(diff_val.to_json(orient='records'))
                    diff = json.loads(diff.to_json(orient='records'))
    return {"diff_val":diff_val,"diff":diff,"diffval_columns":diffval_columns,"diff_columns":diff_columns}
    
