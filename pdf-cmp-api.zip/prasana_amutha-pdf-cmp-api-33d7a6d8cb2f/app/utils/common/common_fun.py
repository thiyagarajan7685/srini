import os
from app import app
from werkzeug.utils import secure_filename

def remove_file(path):
    try:
        os.remove(path)
    except Exception as e:
        print(e)
    return True

def save_file_local(file):
    file_path = os.path.join(
            app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(file_path)
    return file_path