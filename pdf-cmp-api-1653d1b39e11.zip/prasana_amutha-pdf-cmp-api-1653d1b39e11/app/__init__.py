from flask import Flask
from flask_cors import CORS
import os

app = Flask(__name__)

CORS(app)
UPLOAD_FOLDER = 'uploads'
IMG_ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
PDF_ALLOWED_EXTENSIONS = {'pdf'}
DOC_ALLOWED_EXTENSIONS = {'doc','docx'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


from app import views