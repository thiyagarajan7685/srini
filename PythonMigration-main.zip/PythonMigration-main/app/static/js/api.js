function removeChild(pk) {
    const myTabs = document.getElementById(pk);
    while (myTabs.firstChild) {
        myTabs.removeChild(myTabs.firstChild);
    }
}

function highlight_text(val, deprec_mgmt, key) {
    let valHighlighted = val.replace(
        new RegExp(Object.keys(deprec_mgmt).join('|'), 'g'),

        match => {
            let value = deprec_mgmt[match];
            if (match in deprec_mgmt) {

                return `<span style="color: yellow;">${key ? match : value}</span>`;
            } else {
                return `<span style="color: white;">${match}</span>`;
            }
        }
    );
    return '<code class="python" style="white-space: pre-wrap;">' + valHighlighted + '</code>';
}

function files_version(data) {
    // Handle the response data as needed
    const migrate_code = $('#migrate_code');
    const jsonData = data
    removeChild('myTabs')
    removeChild('myTabContent')
    // $('#files_version')[0].reset();
    migrate_code.show();
    jsonData.codes.forEach((code, index) => {
        if (code.get_package_version && code.deprec_mgrt && code.file_contents) {
            // Create a list item for the tab header
            const tabHeader = document.createElement('li');
            tabHeader.className = 'nav-item';
            if (index === 0) {
                tabHeader.innerHTML = `<a class="nav-link active show" data-toggle="tab" href="#tab_${index}">${code.filename}</a>`;

            } else {
                tabHeader.innerHTML = `<a class="nav-link" data-toggle="tab" href="#tab_${index}">${code.filename}</a>`;
            }

            // Create a div for the tab content
            const tabContent = document.createElement('div');
            tabContent.id = `tab_${index}`;
            if (index === 0) {
                tabContent.className = ' accordion tab-pane active show';
            } else {
                tabContent.className = ' accordion tab-pane ';

            }
            document.getElementById('myTabs').appendChild(tabHeader);
            const inputGroupDiv = $('<div class="input-group mb-3">');

            // Create the hidden input element with an incremental name
            const hiddenInput = $(`<input class="form-control" name=${code.filename} type="text" hidden value="${code.file_contents}" /></div>`);

            inputGroupDiv.append(hiddenInput);

            const py_code = highlight_text(code.file_contents, code.deprec_mgrt, true)

            const migrate_code = highlight_text(code.file_contents, code.deprec_mgrt, false)

            // Create the additional code elements
            const codeElements = `
                            <div class="row m-0" style="width:100%">
                                <div class="col">
                                    <h3 class="centered-message p-2 code-title mb-1" style="color: #376f9e;">Before Migrating code</h3>
                                    <div class="code-text p-3">${py_code}</div>
                                </div>

                                <div class="col">
                                    <h3 class="centered-message p-2 code-title mb-1" style="color: #ffcd3d;">After Migrating code</h3>
                                    <div class="code-text p-3" id="${code.filename}">${migrate_code}</div>
                                </div>
                            </div>`;

            const accordionItem = document.createElement('div');
            accordionItem.className = 'accordion-item';

            // Create the h2 element for accordion-header
            const accordionHeader = document.createElement('h2');
            accordionHeader.className = 'accordion-header';
            accordionHeader.id = 'headingOne';
            const accordionButton = document.createElement('button');
            accordionButton.className = 'accordion-button';
            accordionButton.type = 'button';
            accordionButton.setAttribute('data-bs-toggle', 'collapse');
            accordionButton.setAttribute('data-bs-target', '#collapseOne');
            accordionButton.setAttribute('aria-expanded', 'true');
            accordionButton.setAttribute('aria-controls', 'collapseOne');
            accordionButton.textContent = 'Accordion Item #1';

            // Append the button to the h2 element
            accordionHeader.appendChild(accordionButton);

            // Append the h2 element to the accordion-item div
            accordionItem.appendChild(accordionHeader);

            // Assuming you have a parent element (e.g., accordionContainer) where you want to append the accordion-item



            // Create and populate the package version table
            const packageTable = document.createElement('table');
            packageTable.className = 'table table-bordered';
            const packageThead = document.createElement('thead');
            packageThead.className = 'thead-dark';
            const packageHeadRow = document.createElement('tr');

            const packageHeadName = document.createElement('th');
            packageHeadName.textContent = 'Package Name';
            const packageHeadVersion = document.createElement('th');
            packageHeadVersion.textContent = 'Version';

            packageHeadRow.appendChild(packageHeadName);
            packageHeadRow.appendChild(packageHeadVersion);
            packageThead.appendChild(packageHeadRow);

            const packageTbody = document.createElement('tbody');

            for (const packageName in code.get_package_version) {
                const packageRow = document.createElement('tr');
                const packageVersion = code.get_package_version[packageName] || '-';

                const packageNameCell = document.createElement('td');
                packageNameCell.textContent = packageName;
                const packageVersionCell = document.createElement('td');
                packageVersionCell.textContent = packageVersion;

                packageRow.appendChild(packageNameCell);
                packageRow.appendChild(packageVersionCell);

                packageTbody.appendChild(packageRow);
            }

            packageTable.appendChild(packageThead);
            packageTable.appendChild(packageTbody);

            accordionItem.appendChild(packageTable);
            tabContent.appendChild(packageTable);
            // tabContent.appendChild(accordionItem);

            // Create and populate the deprecated management table if available
            if (code.deprec_mgrt) {
                const deprecatedTable = document.createElement('table');
                deprecatedTable.className = 'table table-bordered';
                const deprecatedThead = document.createElement('thead');
                deprecatedThead.className = 'thead-dark';
                const deprecatedHeadRow = document.createElement('tr');

                const deprecatedHeadName = document.createElement('th');
                deprecatedHeadName.textContent = 'Deprecated';
                const deprecatedHeadReplacement = document.createElement('th');
                deprecatedHeadReplacement.textContent = 'Replacement';

                deprecatedHeadRow.appendChild(deprecatedHeadName);
                deprecatedHeadRow.appendChild(deprecatedHeadReplacement);
                deprecatedThead.appendChild(deprecatedHeadRow);

                const deprecatedTbody = document.createElement('tbody');
                const length = Object.keys(code.deprec_mgrt).length;

                if (code.deprec_mgrt && length) {
                    for (const deprecatedName in code.deprec_mgrt) {
                        const deprecatedRow = document.createElement('tr');
                        const deprecatedReplacement = code.deprec_mgrt[deprecatedName];

                        const deprecatedNameCell = document.createElement('td');
                        deprecatedNameCell.textContent = deprecatedName;
                        const deprecatedReplacementCell = document.createElement('td');
                        deprecatedReplacementCell.textContent = deprecatedReplacement;

                        deprecatedRow.appendChild(deprecatedNameCell);
                        deprecatedRow.appendChild(deprecatedReplacementCell);

                        deprecatedTbody.appendChild(deprecatedRow);
                    }
                } else {
                    const noDataRow = document.createElement('tr');
                    const noDataCell = document.createElement('td');
                    noDataCell.setAttribute('colspan', 2); // Span the entire row
                    noDataCell.classList.add('centered-message'); // Add a CSS class
                    noDataCell.textContent = 'No data is found';
                    noDataRow.appendChild(noDataCell);

                    deprecatedTbody.appendChild(noDataRow);
                }

                deprecatedTable.appendChild(deprecatedThead);
                deprecatedTable.appendChild(deprecatedTbody);

                tabContent.appendChild(deprecatedTable);
                deprecatedTable.insertAdjacentHTML('afterend', codeElements);

            }

            // Add the tab content to the tab content container
            document.getElementById('myTabContent').appendChild(tabContent);
            // Add the tab header to the ul


        }
    });
}

function ajaxApi(method, url, data, processData, contentType) {
    $.ajax({
        type: method,
        url: url,
        data: data,
        processData: processData, // Prevent jQuery from processing the data
        contentType: contentType, // Set content type to false to allow the browser to set it automatically
        success: function (data) {
            if (url === 'files_version') {
                files_version(data)
            } else if (url === 'file_migrate') {
                $("#download-link").show()
            } else if (url === "generate_deprec") {
                $("#depr-spinner").hide()
                $("#deprected").show()
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            const toast = $('#toast');
            let error_message = 'Something Went Wrong'
            if (jqXHR.status === 400) {
                const errorResponse = JSON.parse(jqXHR.responseText);
                error_message = errorResponse.message
            }
            if (url === "generate_deprec") {
                $("#depr-spinner").hide()
                $("#deprected").show()
            }
            toast.text(error_message);
            toast.show();
            setTimeout(function () {
                toast.hide();
            }, 5000);
            

        }
    });
}

$(document).ready(function () {
    $('#files_version').submit(function (event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Create a FormData object to collect the form data
        const data = new FormData(this);
        const url = 'files_version'
        const method = 'POST'
        ajaxApi(method, url, data, false, false)

        // Make an AJAX API call using jQuery's $.ajax method

    });
});


    function extractFilenameAndCode() {
    const output = {};

    // Iterate through each code-text element
    document.querySelectorAll('.code-text').forEach((codeText, index) => {
        // Get the filename from the id attribute
        const filename = codeText.id;

        // Get the code content
        const codeContent = codeText.querySelector('code').innerText.trim();

        if (filename) {
            output[filename] = codeContent;
        }

    });

    return output
}

$(document).ready(function () {
    $('#file_migrate').submit(function (event) {
        event.preventDefault(); // Prevent the default form submission behavior

        const output = extractFilenameAndCode();
        const url = 'file_migrate'
        const method = 'POST'
        const data = JSON.stringify(output);
        ajaxApi(method, url, data, false, "application/json")

        // Make an AJAX API call using jQuery's $.ajax method

    });
});


function generate_deprec() {
    $("#deprected").hide()
    $("#depr-spinner").show()
    ajaxApi("GET", "generate_deprec", null, false, "application/json")

}
