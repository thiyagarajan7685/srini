

async function ajaxApi(method, url, data, processData, contentType) {
    try {
        const response = await $.ajax({
            type: method,
            url: url,
            data: data,
            processData: processData, // Prevent jQuery from processing the data
            contentType: contentType, // Set content type to false to allow the browser to set it automatically
        });

        // Return the response data
        return response;
    } catch (error) {
        // Handle errors
        const toast = $('#toast');
        let error_message = 'Something Went Wrong';
        if (error.status === 400) {
            const errorResponse = JSON.parse(error.responseText);
            error_message = errorResponse.message;
        }
        toast.text(error_message);
        toast.show();
        setTimeout(function () {
            toast.hide();
        }, 5000);
    }
}



function highlight_text(parse_data, key) {
    let val = JSON.parse(parse_data)
    let valHighlighted = val.file_contents
    let deprec_mgmt = val.deprec_mgrt
    if (deprec_mgmt) {
        valHighlighted = valHighlighted.replace(
            new RegExp(Object.keys(deprec_mgmt).join('|'), 'g'),

            match => {
                let value = deprec_mgmt[match];
                if (match in deprec_mgmt) {

                    return `<span style="color: yellow;">${key ? match : value}</span>`;
                } else {
                    return `<span style="color: white;">${match}</span>`;
                }
            }
        );

    }
    return '<code class="python" style="white-space: pre-wrap;">' + valHighlighted + '</code>';

}

async function migrate_code_preview(file_path, id) {
    var ver = $("#version").text();
    const data_json = { version: ver, filepath: file_path, filename: id };
    const data = JSON.stringify(data_json);
    const url = 'file_migrate_api'
    const method = 'POST'
    var output = await ajaxApi(method, url, data, false, "application/json")

    // Get the parse_json object
    var parse_json = output['codes'][id];
    var parse_data = parse_json['parse_json'];

    var allElements = document.querySelectorAll('p');
    allElements.forEach(function (pElement) {

        var changeElement = document.getElementById(pElement.id);

        if (pElement.id == id) {
            changeElement.style.backgroundColor = "#2d61b0";

        }
        else {
            changeElement.style.backgroundColor = "#2f3b43";
        }
    });

    var spanText = document.getElementById(id+"_size")

    // Print the text content to the console
    spanText.textContent = parse_json["size"];
    const py_code = highlight_text(parse_data, true)

    const beforeMigrateDiv = document.getElementById("before-migrate");
    beforeMigrateDiv.innerHTML = py_code;

    const migrate_code = highlight_text(parse_data, false)
    const afterMigrateDiv = document.getElementById("after-migrate");

    afterMigrateDiv.innerHTML = migrate_code;

}

function downloadBase64File(base64Data, fileName) {
    const blob = base64toBlob(base64Data);
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
}

function base64toBlob(base64Data) {
    const byteCharacters = atob(base64Data);
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }
    return new Blob(byteArrays, { type: 'application/octet-stream' });
}

function migrate_action(unique_id){
    const version = $("#version").text()
    const data_json = {unique_id:unique_id,version:version};
    const data = JSON.stringify(data_json);
    const url = 'file_migrate'
    const method = 'POST'
    ajaxApi(method, url, data, false, "application/json")
    .then(response => {

        const base64Data = response.output_file; // Assuming the base64 data is in the output_file field
        const fileName = response.filename; // Provide the desired file name with the correct extension
        downloadBase64File(base64Data, fileName);
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

