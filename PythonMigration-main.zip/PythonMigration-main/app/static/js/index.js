// Get the file input and label element
const fileInput = document.getElementById('inputGroupFile01');
const fileLabel = document.querySelector('.custom-file-label');

// Add an event listener to the file input
fileInput.addEventListener('change', function () {
    // Check if a file is selected
    if (fileInput.files.length > 0) {
        // Update the label text to show the selected file name
        fileLabel.textContent = fileInput.files[0].name;
    } else {
        // If no file is selected, reset the label text
        fileLabel.textContent = 'Choose file';
    }
});