from flask import render_template, request, send_file
from app.utils.folder_html import folder_code_html,file_html
from app.utils.get_version import get_pkg_ver
import json
import os
import platform
from zipfile import ZipFile, ZIP_DEFLATED
import shutil
from io import BytesIO
from app.utils.request_handler import ok_request, notok_request
from app.utils.webscrapy_main import scrapy_release_link,deprected_fun,read_deprected_link
import uuid
import glob
import base64


platform_version = platform.python_version()


def convert_deprecated_functions(old_migrate_version, code, mapping, convert):
    replacements = mapping.get(old_migrate_version, [])
    get_deprect_migrate = {}
    
    if replacements:
        for replacement in replacements:
            deprecated_function = replacement["deprecated_function"]
            replacement_function = replacement["replacement"]
            if convert:
                code = code.replace(deprecated_function, replacement_function)
            else:
                if deprecated_function in code:
                    get_deprect_migrate[deprecated_function] = replacement_function
        return code if convert else get_deprect_migrate
    return False


def get_file_size(file):
    file_size_bytes = len(file)
    file_size_kb = file_size_bytes / 1024
    file_size_mb = file_size_kb / (1024)
    
    threshold_mb = 1  # For example, if size exceeds 1 MB, return MB
    
    if file_size_mb > threshold_mb:
        return "{:.2f} MB".format(file_size_mb)
    else:
        return "{:.2f} KB".format(file_size_kb)



def deprected_file():
    deprecated_mapping = {}
    with open("app/static/deprecated_mapping.json", "r") as mapping_file:
        deprecated_mapping = json.load(mapping_file)
    return deprecated_mapping


def home():
    return render_template('home.html')


def index():
    versions = read_deprected_link()
    return render_template('index.html', platform_version=platform_version,versions=versions)

def before_migrate(input_code, filename,version):
        deprecated_mapping = deprected_file()
        codes = {}
        file_contents = input_code.read()
        if type(file_contents) != type("str"):
            file_contents_str = file_contents.decode('utf-8')
        else:
            file_contents_str = file_contents
        get_package_version = get_pkg_ver(file_contents_str)
        old_migrate_version = version if version else f"{3.6}-{3.7}"
        updated_code = convert_deprecated_functions(
            old_migrate_version, file_contents_str, deprecated_mapping, False)
        migrate_code = {"parse_json":json.dumps({"deprec_mgrt": updated_code,
                        "get_package_version": get_package_version, 'file_contents': file_contents_str}),"size":get_file_size(file_contents)}
        codes[filename] = migrate_code
        return codes


def zip_directory_structure(directory,version):
    structure = {}
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isdir(item_path):
            structure[item] = zip_directory_structure(item_path,version)
        elif item.endswith(".py"):
        
            if item.split('.')[-1] == "py":
                    file_path = os.path.join(directory, item)
                    codes = {item:file_path.replace('\\','/')}                    
            if curr_dict := structure.get("file"):
                    curr_dict.append(codes)
            else:
                structure['file'] = [codes]
            
    return structure


def version_file():
    uploaded_file = request.files['file']
    version = request.form['version']
    file_method = None
    if uploaded_file and uploaded_file.filename.split('.')[-1] in ['py', 'zip']:

        unique_id = str(uuid.uuid4())
        #copy to migrate folder
        migrate_folder = os.path.join('migrated')
        target_directory = os.path.join(migrate_folder, unique_id)
    
        # Create the target directory
        os.makedirs(target_directory, exist_ok=True)
        if uploaded_file.filename.split('.')[-1] == "py":
            file_path = os.path.join('uploads', uploaded_file.filename)
            item = file_path.replace('\\','\\\\')
            structure = [{uploaded_file.filename:item}]
            file_method = "py"
            codes = file_html(structure)
            uploaded_file.save(item)
            uploaded_file.stream.seek(0)
            migrate_file_path = os.path.join(target_directory, uploaded_file.filename)
            uploaded_file.save(migrate_file_path)

        elif uploaded_file.filename.split('.')[-1] == "zip":
            file_method = "zip"
            filename_without_extension = uploaded_file.filename.replace(".zip","")
            
            uploads_folder = os.path.join('uploads', filename_without_extension)

            if not os.path.exists(uploads_folder):
                os.makedirs(uploads_folder)

            zip_path = os.path.join(uploads_folder, uploaded_file.filename)
            uploaded_file.save(zip_path)

            # Extract the zip file
            with ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(uploads_folder)

            migrate_file_path = os.path.join(target_directory,filename_without_extension)
            with ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(uploads_folder)
                zip_ref.extractall(migrate_file_path)
            structure = zip_directory_structure(uploads_folder,version)
            
            codes = folder_code_html(structure)
        else:
            return render_template('home.html')
        return render_template('migration.html', codes=codes,version=version,file_method=file_method,unique_id=unique_id)
    return render_template('home.html')


def file_migrate_api():
    version = request.json.get('version')
    filepath = request.json.get('filepath')
    filename = request.json.get('filename')
    cwd = os.getcwd()
    file_path = os.path.join(cwd, filepath)
    with open(file_path) as file:
        codes =  before_migrate(file, filename,version)
    return ok_request({"codes":codes})

def process_file(file_path,version,deprecated_mapping):
    filename = os.path.basename(file_path)
    with open(file_path,'r') as file:
        codes =  before_migrate(file, filename,version)
        input_code = json.loads(codes[filename]['parse_json'])
        updated_code = convert_deprecated_functions(version, input_code['file_contents'], deprecated_mapping, True)

        with open(file_path, 'w') as file:
            file.write(updated_code)

        

def find_and_process_python_files(directory,version):
    python_files = glob.glob(os.path.join(directory, '**', '*.py'), recursive=True)
    deprecated_mapping = deprected_file()
    # Process each Python file
    for python_file in python_files:
        print(f"Processing {python_file}")
        process_file(python_file,version,deprecated_mapping)

def find_folder(uploads_folder):
    # Check if the folder exists
    if not os.path.exists(uploads_folder):
        return {"error": "Folder not found"}

    folder_name = None
    # Iterate over the contents of the folder
    for item in os.listdir(uploads_folder):
        item_path = os.path.join(uploads_folder, item)
        # Check if the item is a directory
        if os.path.isdir(item_path):
            # If folder_name is already set, it means there are multiple folders
            if folder_name is not None:
                return {"error": "Multiple folders found inside uploads_folder"}
            folder_name = item

    if folder_name is None:
        return {"error": "No folder found inside uploads_folder"}

    return folder_name

def zip_folder(folder_path, zip_path):
    with ZipFile(zip_path, 'w', ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))

def convert_to_base64(file_path):
    with open(file_path, "rb") as file:
        encoded_string = base64.b64encode(file.read()).decode('utf-8')
    return encoded_string

def migrate_file():

    json_data = request.get_json()
    unique_id = json_data.get('unique_id')
    version = json_data.get('version')
    uploads_folder = os.path.join('migrated', unique_id)
    find_and_process_python_files(uploads_folder,version)
    contents = os.listdir(uploads_folder)

    # If there's only one file, send it directly
    if len(contents) == 1 and os.path.isfile(os.path.join(uploads_folder, contents[0])):
        file_path = os.path.join(uploads_folder, contents[0])
        with open(file_path, 'rb') as file:
            file_data = file.read()
            base64_encoded_data = base64.b64encode(file_data).decode('utf-8')
            filename = os.path.basename(file_path)
            return {"message": "Migrated successfully", "output_file": base64_encoded_data,"filename":filename}

    # If there are multiple files or folders, create a zip file
    else:
        folder_name = os.listdir(uploads_folder)[0]
        folder_path = os.path.join(uploads_folder, folder_name)

        # Create zip file path
        zip_path = os.path.join(uploads_folder, f"{folder_name}.zip")

        # Zip the folder
        zip_folder(folder_path, zip_path)

        # Convert the zip file to base64
        base64_string = convert_to_base64(zip_path)

        return {"message": "Migrated successfully", "output_file": base64_string,"filename":f"{folder_name}.zip"}




def download():
    project_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    output_path = f"{project_path}\migrated"
    memory_file = BytesIO()
    abs_src = os.path.abspath(output_path)
    with ZipFile(memory_file, 'w', ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(output_path):
            try:
                for file in files:
                    absname = os.path.abspath(os.path.join(root, file))
                    arcname = absname[len(abs_src) + 1:]
                    zipf.write(absname, arcname)
            except Exception as e:
                print(e)
    memory_file.seek(0)
    if os.path.exists(output_path):
        shutil.rmtree(output_path)
    return send_file(memory_file, as_attachment=True, download_name='output.zip')


def generate_deprec():
    status = scrapy_release_link()
    if status:
        return ok_request({"message":"Generated Deprected Json successfully"})
    return notok_request({"message": "Something Wrong!"})


def extract_deprec():
    status = deprected_fun("3.12.2")
    if status:
        return ok_request({"message":"Extracted Deprected successfully","removed_deprected":status})
    return notok_request({"message": "Something Wrong!"})