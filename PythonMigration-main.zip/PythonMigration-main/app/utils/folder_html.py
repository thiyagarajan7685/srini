

def file_html(val):
    #[{'output_code.py': 'uploads/deprected_migratons1/deprected_migratons/folder2/folder2_1/output_code.py'}]
    html = ""
    for i in val:
        for j in i:
            path = i[j]
            html += f"""
            <li onclick='migrate_code_preview("{ path }", "{ j }")'>
                                                    <p class="mb-0" style="padding-left:2px;" id="{j}"><i class="fa-brands fa-python"
                                                            style="color: #4B8BBE;"></i>{j} <span id="{j}_size"></span>
                                                       
                                                    </p>
                                                     <span id="{j}_path" style="display: none;">{path}</span>
                                                </li>

            """

    return html


def folder_html(dt, structure):
   
    code = f""" 
    
        <li>
            <details>
                <summary><i class="fa fa-folder"></i> {dt}</summary>
           
            <ul> 
    """
    for i in structure[dt]:
        if i == "file":
            html = file_html(structure[dt][i])
            code += f" {html}\n"
        else:
            code += folder_html(i, structure[dt])
    code += """        </ul>  </details>
        </li>
    
    """

    return code


def folder_code_html(structure):
    html = ""
    for i in structure:
        if i != "file":
            html += folder_html(i, structure)
        else:
            html += file_html(structure[i])
            
    return html
