import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Compare from './components/compare';
import ErrorPage from './components/error-page';
import Extract from './components/extract';
import Home from './components/home';
import ModernLogin from './components/login';
import Dashboard from './components/dashboard';

const authenticated = localStorage.getItem('authToken');

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={authenticated ? <Home /> : <Navigate to="/login" replace />} />
          <Route path="/dashboard" element={authenticated ? <Dashboard /> : <Navigate to="/login" replace />} />
          <Route path="/compare" element={authenticated ? <Compare /> : <Navigate to="/login" replace />} />
          <Route path="/extract" element={authenticated ? <Extract /> : <Navigate to="/login" replace />} />
          <Route path="/login" element={!authenticated ? <ModernLogin /> : <Navigate to="/" replace />} />
          <Route path="*" element={<ErrorPage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
