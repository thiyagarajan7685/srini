import * as React from 'react';
import { Button, Grid, CardContent, Typography, Paper } from '@mui/material';
import { Textarea } from './form_input';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';


// const formData = new FormData();
// formData.append('email', email)


export default function TextTab() {

    const [sourceTxt, setSourceTxt] = React.useState("");
    const [destTxt, setDestTxt] = React.useState("");
    const [highlightedSentence, setHighlightedSentence] = React.useState(null);
    const [counts, setCounts] = React.useState(null);
    
    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg,sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };



    const textCompare = async () => {
        try {

            if (!sourceTxt && !destTxt) {
                handleClick("Please fill all the fields", "error")
                return
            }
            const jsonData = { gd_txt: sourceTxt, cp_txt: destTxt }

            const response = await AuthServices.textCmp(jsonData);
            if (response) {
                const words = response.output.ins_del.split(' ');
                const sentence = words.map((word, index) => {
                    if (response.output.delete.includes(index)) {
                        return <span key={index.id} style={{ color: 'red',textDecoration: 'line-through' }}>{word}&nbsp;</span>;
                    } else if (response.output.insert?.includes(index)) {
                        return <span key={index.id} style={{ color: 'green' }}>{word}&nbsp;</span>;
                    } else {
                        return <span key={index.id}>{word}&nbsp;</span>;
                    }
                });


                setHighlightedSentence(sentence)
                setCounts(response.total_word_count)
            }
        } catch (err) {
            const { data } = err || {}
            const { message } = data || {}
            if (message) {
                const data = { message, class: 'error' }
                console.log(data)
            }
        }

    }

    return (
        <>
            <SnackbarAlert
                severity={severity}  
                message={message}
                open={open}
                handleClose={handleClose}
            />
            <Grid container rowSpacing={2} sx={{marginX:5}}>
                <Grid item xs={12} md={6} >
                    <Textarea aria-label="minimum height" minRows={8} placeholder="Source Text" onChange={(event) => setSourceTxt(event.target.value)} required />
                </Grid>
                <Grid item xs={12} md={6}>
                    <Textarea aria-label="minimum height" minRows={8} placeholder="Compare Text" onChange={(event) => setDestTxt(event.target.value)} required />
                </Grid>
            </Grid>
            <Grid
                container
                direction="row"
                justifyContent="center"
                alignItems="center"
                sx={{ marginTop: 5 }}
            >
                <Grid item >
                    <Button size="large" sx={{backgroundColor:"#70007d", color:"white"}} color="secondary" variant="contained" onClick={textCompare} >Compare</Button>
                </Grid>
            </Grid>
            <Grid
                container
                direction="row"
                justifyContent="center"
                alignItems="center"
                sx={{ marginTop: 5 }}
            >
                <Grid item xs={6}>
                    {(highlightedSentence ? 
                        
                        <div>
                            <h2>Comparison Result </h2>
                            <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center">
                                <Grid item xs={12} md={4} sm={12} >
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'  > Total Words </Typography>
                                            <Typography variant='h4' component='h4'  >  {counts?.total_words}</Typography>
                                        </CardContent>
                                    </Paper>
                                </Grid>
                                <Grid item xs={12} md={4} sm={6}>
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'  > Total Inserted Words </Typography>
                                            <Typography variant='h4' component='h4' color='green'  > {counts?.insert}</Typography>
                                        </CardContent>
                                    </Paper>
                                </Grid>
                                <Grid item xs={12} md={4} sm={6}>
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'> Total Deleted Words </Typography>
                                            <Typography variant='h4' component='h4' color='red'> {counts?.delete}</Typography>
                                        </CardContent>

                                    </Paper>
                                </Grid>
                            

                            </Grid>

                            <Grid container spacing={2} alignItems="center" justifyContent="center" sx={{marginTop:3}}>

                                {highlightedSentence}
                            </Grid>
                        </div>
                         
                        
                        
                        : "")}

                </Grid>
            </Grid>
        </>
    )
}