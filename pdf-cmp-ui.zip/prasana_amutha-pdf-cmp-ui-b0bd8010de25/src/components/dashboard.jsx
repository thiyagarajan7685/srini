import * as React from 'react';
import Navbar from './navbar'
import Compare from './compare';
import { Box, Typography, Grid, Paper, CardContent, } from '@mui/material';
import { PieChart } from '@mui/x-charts/PieChart';
import AuthServices from '../api/auth-services';

const gridItems = [
    {
        title: 'Total Words compared',
        value: 123,

    },
    {
        title: 'Total Files Compared',
        value: 543,

    },
    {
        title: 'Total Images Compared',
        value: 312,

    }
];

function Dashboard() {

    const [dashboardData, setDashboardData] = React.useState(null);

    React.useEffect(() => {
        async function fetchData() {
            try {
                let response = await AuthServices.dashboard();

                if (response) {
                    setDashboardData(response.output);
                }
            } catch (err) {
                const { data } = err || {};
                const { message } = data || {};
            }
        }

        fetchData();
    }, []);


    return (
        <>
            <Navbar />
            <Box maxWidth="xl" gap={4} sx={{ marginY: 5, marginX: 10 }} >
                <Grid container spacing={1} alignItems="center" justifyContent="center" textAlign="center">
                    <Grid item xs={12} md={12} sm={12} >
                        <h2>Comparison Usage </h2>
                    </Grid>


                    {dashboardData?.total_compare.map((item, index) => (
                        <Grid key={index} item xs={12} md={4} sm={6}>
                            <Paper elevation={4} sx={{ margin: 2, minHeight: 150 }}>
                                <CardContent>
                                    <Typography variant='h6' component='h6' sx={{ fontWeight: "bolder" }}>
                                        {item.title}
                                    </Typography>
                                    <Typography variant='h4' component='h4' color='#7d007d' margin={2} >
                                        {item.value}
                                    </Typography>
                                </CardContent>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>
                <Grid container spacing={1} alignItems="center" justifyContent="center" textAlign="center" sx={{border: "2px solid #cccccc",boxShadow:"0 4px 6px rgba(0, 0, 0, 0.1)", marginTop:2}}>
                    <Grid item xs={12} md={8} sm={12}  sx={{margin:2}}>
                        <h1>Files Comparison Overview </h1>
                        <PieChart 
                            series={[
                                {
                                    data:dashboardData ? dashboardData.total_files_compare : [],
                                },
                            ]}
                            width={850}
                            height={400}
                        />
                    </Grid>
                    <Grid item xs={12} md={3} sm={12} sx={{margin:2}}>
                        {dashboardData?.total_files_compare.map((item, index) => (

                            <Paper key={index} elevation={2} sx={{ margin: 1, minHeight: 150 }}>
                                <CardContent>
                                    <Typography variant='h6' component='h6' sx={{ fontWeight: "bolder" }}>
                                        {item.label}
                                    </Typography>
                                    <Typography variant='h4' component='h4' color="7d007d" margin={2} >
                                        {item.value}
                                    </Typography>
                                </CardContent>
                            </Paper>

                        ))}
                    </Grid>



                </Grid>
            </Box>
        </>

    )
}


export default Dashboard;