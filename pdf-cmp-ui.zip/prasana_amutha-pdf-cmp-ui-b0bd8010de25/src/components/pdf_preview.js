import { useState } from 'react';
import { pdfjs, Document, Page } from 'react-pdf';
import './doc.css'

function PdfPreview({ pdf,currentPage,SetTotalPages }) {

    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        'pdfjs-dist/build/pdf.worker.min.js',
        import.meta.url,
    ).toString();

    const [numPages, setNumPages] = useState(0);
    
    SetTotalPages(numPages)

    function onDocumentLoadSuccess({ numPages }) {
        setNumPages(numPages);
    }

   

    return (
        <div className='pdf-page-layout'>
            
            <Document file={pdf} onLoadSuccess={onDocumentLoadSuccess} options={{ workerSrc: "pdf.worker.js" }}>

                <div key={currentPage} style={{textAlign:'center'}}>
                    <p >{currentPage}</p>
                    <Page size="A4" pageNumber={currentPage} renderTextLayer={false} renderAnnotationLayer={false} />

                </div>
            </Document>

        </div>
    );
}

export default PdfPreview