import * as React from 'react';
import { Button, Grid, CardContent, Typography, Paper, Tooltip } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { Box, styled } from '@mui/system';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import DescriptionIcon from '@mui/icons-material/Description';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PdfPreview from './pdf_preview';
import ArticleIcon from '@mui/icons-material/Article';
import ReactJson from 'react-json-view'

export default function DocTab() {

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState(null);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);
    const [highlightedtable, setHighlightedtable] = React.useState(null);
    const [columnstable, setColumnstable] = React.useState(null);
    const [dataTable, setDataTable] = React.useState(null);
    const [openLoader, setOpenLoader] = React.useState(false);

    const [Selected, setSelected] = React.useState(null);

    const [currentPage, setCurrentPage] = React.useState(1);

    const [srcTotalPages, SetSrcTotalPages] = React.useState(1);

    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });

    const handleFileType = (file) => {
        const fileType = file.type;
        if (fileType === 'application/pdf') {
            return 'pdf_text'
        } else if (fileType === 'application/json') {
            return 'json_text'
        }
        else {
            return 'docs_text'
        }
    }

    const handleSourceFileChange = (event, value) => {
        const file = event.target.files[0];
        const fileType = file.type;
        setHighlightedtable(highlightedtable)

        if (file && isDocument(file)) {
            if (value === "source") {
                setSourceFile(file)

                setSelected(handleFileType(file))

            } else if (value === "dest") {
                if (Selected === null) {
                    handleClick("Select the Source file", "error")
                }
                else if (fileType !== 'application/pdf' && Selected === 'pdf_text') {
                    handleClick("Accept only PDF file", "error")
                } else if (fileType !== 'application/json' && Selected === 'json_text') {
                    handleClick("Accept only JSON file", "error")
                } else if ((fileType === 'application/pdf' || fileType === 'application/json') && Selected === 'docs_text') {
                    handleClick("Accept only DOCX file", "error")
                }
                else {
                    setCompareFile(file)

                }

            }

        } else {
            handleClick("Accept only document file", "error")
        }
    };

    const getFileIcon = (fileType) => {
        if (fileType === 'application/pdf') {
            return <PictureAsPdfIcon color='error' />;
        } else if (fileType.startsWith('application/json')) {
            return <ArticleIcon color='warning' />;
        } else {
            // Default icon or handle other document types
            return <DescriptionIcon color='primary' />;
        }
    };

    const isDocument = (file) => {
        return (

            file.type === 'application/pdf' || file.type === 'application/json' ||
            file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        );
    };

    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {


        const formData = new FormData();

        formData.append('gd_file', sourceFile);
        formData.append('cp_file', compareFile);


        if (!Selected) {
            handleClick("Source and Test File are Differenet!", "error")
            return
        }
        setOpenLoader(true);
        try {
            let response = {}
            setHighlightedtable(highlightedtable)
            setDataTable(dataTable)
            setColumnstable(columnstable)
            setHighlightedSentence(highlightedSentence)


            if (Selected === 'docs_text') {
                response = await AuthServices.docsCmp(formData);
            } else if (Selected === 'pdf_text') {
                response = await AuthServices.pdfCmp(formData);
            } else if (Selected === 'json_text') {
                response = await AuthServices.jsonCmp(formData);
            }
            else {
                response = await AuthServices.tableCmp(formData);
            }



            if (response) {
                if (Selected === 'docs_text' || Selected === 'pdf_text' || Selected === 'json_text') {
                    setHighlightedSentence(response.output)
                    setCompareFile(compareFile)
                    setSourceFile(sourceFile)
                }
                else {

                    const diffData = (response.output.diff);
                    const diffValData = (response.output.diff_val);
                    const diffValColumns = (response.output.diffval_columns);
                    setHighlightedtable(diffValData)
                    setDataTable(diffData)
                    setColumnstable(diffValColumns)
                }

            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }

    function handlePreview(base64Data) {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        return url
    }

    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };
    const handleDroptest = (event) => {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        setCompareFile(file);
    };
    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            setSourceFile(file);
        }
    };

    const goToPreviousPage = () => {
        setCurrentPage((prevPage) => Math.max(prevPage - 1, 1)); // Ensure page number doesn't go below 1
    };

    const goToNextPage = () => {
        setCurrentPage((prevPage) => Math.min(prevPage + 1, srcTotalPages)); // Ensure page number doesn't exceed total pages
    };


    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="flex-start" direction="row" sx={{ paddingX: 4 }}>

                <Grid item xs={12} md={6} >
                    <Box onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        className='drag-box'>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Source File
                            <VisuallyHiddenInput type="file" accept=".pdf,.json,.docx" onChange={(event) => handleSourceFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PDF, DOCX, JSON">
                            <InfoOutlinedIcon color="disabled" fontSize="small" sx={{ marginX: "4px" }} />
                        </Tooltip>
                        {sourceFile ?
                            <Typography variant="subtitle1" color="textSecondary">
                                {getFileIcon(sourceFile.type)}  <strong>Source Document:</strong> {sourceFile.name}
                            </Typography>

                            : (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                    </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                    <Box onDrop={handleDroptest}
                        onDragOver={handleDragOver}
                        className='drag-box'
                    >
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept=".pdf,.json,.docx" onChange={(event) => handleSourceFileChange(event, "dest")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PDF, DOCX, JSON">
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>
                        {compareFile && (
                            <Typography variant="subtitle1" color="textSecondary">
                                {getFileIcon(compareFile.type)} <strong>Compare Document:</strong> {compareFile.name}
                            </Typography>
                        )}
                        {!compareFile && (
                            <Typography variant="subtitle1" color="textSecondary">
                                Drag and Drop
                            </Typography>
                        )}
                    </Box>
                </Grid>

            </Grid>


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />

            {highlightedSentence?.total_words && (

                <div>
                    <h2>Comparison Result </h2>
                    <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center" textAlign="center">
                        <Grid item xs={12} md={4} sm={12} >
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'  > Total Words </Typography>
                                    <Typography variant='h4' component='h4'  >  {highlightedSentence?.total_words}</Typography>
                                </CardContent>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={4} sm={6}>
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'  > Total Inserted Words </Typography>
                                    <Typography variant='h4' component='h4' color='green'  > {highlightedSentence?.insert}</Typography>
                                </CardContent>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={4} sm={6}>
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'> Total Deleted Words </Typography>
                                    <Typography variant='h4' component='h4' color='red'> {highlightedSentence?.delete}</Typography>
                                </CardContent>

                            </Paper>
                        </Grid>
                        {/* <Button variant="outlined" sx={{ margin: 2 }} color='secondary' onClick={handleExport(highlightedSentence?.report)} endIcon={<FileDownloadIcon />} >Export Report</Button> */}


                    </Grid>
                    <div style={{ textAlign: 'center' }}>
                        <Button size="small" variant="contained" color='secondary' onClick={goToPreviousPage} disabled={currentPage === 1} sx={{ margin: 2, alignItems: 'center' }}>Previous</Button>
                        <Button size="small" variant="contained" color='secondary' onClick={goToNextPage} disabled={currentPage === srcTotalPages} sx={{ margin: 2, alignItems: 'center' }}>Next</Button>
                    </div>
                    <Grid container spacing={1} alignItems="center" justifyContent="center">
                        <Grid item xs={12} md={6} >

                            <h3>Source File</h3>
                            <PdfPreview pdf={handlePreview(highlightedSentence?.gold_base64)} currentPage={currentPage} SetTotalPages={SetSrcTotalPages} />
                        </Grid>

                        <Grid item xs={12} md={6} sx={{ maxWidth: "720px", maxHeight: "792px" }} >

                            <h3 style={{ marginTop: '-3rem' }}>Output File</h3>

                            <div style={{ border: '1px solid #bdbdbd' }}>
                                <div>
                                    <p style={{ backgroundColor: '#b7b4b470', padding: '15px ', marginTop: '-2px', textAlign: 'center' }}>{currentPage}</p>
                                </div>
                                <div style={{ marginBottom: '-76px' }} dangerouslySetInnerHTML={{ __html: highlightedSentence?.html[`Page_${currentPage}`] }} />
                            </div>
                        </Grid>

                    </Grid>
                </div>
            )}
            {highlightedSentence?.json_result && (

                <div>
                    
                    <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center" textAlign="center">
                    <h2>Comparison Result </h2>


                    </Grid>

                    <Grid container spacing={1} justifyContent="center">
                        <Grid item xs={12} md={6} >

                            <h3>Source File</h3>
                            <ReactJson src={highlightedSentence?.gold_json} />
                        </Grid>
                        <Grid item xs={12} md={6} >

                            <h3>Output File</h3>
                            <ReactJson src={highlightedSentence?.json_result} />
                        </Grid>



                    </Grid>
                </div>
            )}
            {highlightedtable && (
                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <Grid item sx={{ margin: 2 }}>
                        <h2>Comparison Result</h2>
                        <div>
                            <table border="1">
                                <thead>
                                    <tr>
                                        {columnstable.map((column, index) => (
                                            <th key={index.id}>{column.join(' / ')}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {highlightedtable.map((record, index) => (
                                        <tr key={index.id}>
                                            {columnstable.map((column, columnIndex) => (
                                                <td key={columnIndex.id} style={{ backgroundColor: dataTable[index][`('${column[0]}', '${column[1]}')`] ? 'yellow' : 'white' }}>
                                                    {record[`('${column[0]}', '${column[1]}')`] ? record[`('${column[0]}', '${column[1]}')`] : '-'}

                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                        </div>

                    </Grid>
                </Grid>
            )}


        </>
    )
}