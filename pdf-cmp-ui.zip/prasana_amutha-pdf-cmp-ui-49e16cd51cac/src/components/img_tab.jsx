import * as React from 'react';
import { Button, Grid, Card, CardContent, Typography, CardHeader, CardMedia, Tooltip } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { styled } from '@mui/system';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import ImageIcon from '@mui/icons-material/Image';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

export default function ImgTab() {
    const [sourceImg, setSourceImg] = React.useState(null);
    const [destImg, setDestImg] = React.useState(null);

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState(null);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);

    const [openLoader, setOpenLoader] = React.useState(false);


    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });


    const handleFileChange = (event, value) => {
        const file = event.target.files[0];
        const fileType = file.type;
        if (file && (fileType === 'image/jpeg' || fileType === 'image/png')) {
            if (value === "source") {
                setSourceImg(file)
            } else if (value === "dest") {
                setDestImg(file)
            }
        } else {
            handleClick("Allowed Image: PNG, JPG", "error")
        }
    };


    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {


        const formData = new FormData();
        formData.append('gd_file', sourceImg);
        formData.append('cp_file', destImg);


        if (!sourceImg && !destImg) {
            handleClick("Please upload the Files", "error")
            return
        }

        setOpenLoader(true);
        try {
            let response = {}
            setHighlightedSentence(highlightedSentence)

            response = await AuthServices.imgCmp(formData);

            if (response) {

                setHighlightedSentence(response.output)
                setCompareFile(compareFile)
                setSourceFile(sourceFile)



            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }


    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };

    const handleDropImage = (event, value) => {
        event.preventDefault();
        if (event.dataTransfer?.files?.length > 0) {
            const file = event.dataTransfer.files[0];

            if (file.type.startsWith('image/')) {
                if (value === "source") {
                    setSourceImg(file);
                } else if (value === "dest") {
                    setDestImg(file);
                }
            } else {
                console.log("Please drop an image file.");
            }
        } else {
            console.log("No files dropped or dataTransfer not supported.");
        }
    };
    const handleDragStart = (event, type) => {
        event.dataTransfer.setData("text/plain", type);
    };


    let cardStyle = { minWidth: "40%", minHeight: 150, margin: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backgroundSize: 'cover', border: "2px dashed #7d007d" }

    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                <Card sx={cardStyle}
                    onDrop={(event) => handleDropImage(event, 'source')} onDragOver={handleDragOver}
                >
                    <CardContent sx={{ marginTop: 3 }}>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button' >
                            Source File
                            <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PNG,JPG" sx={{ marginLeft: 1 }}>
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>

                        <Typography variant="subtitle1" color="textSecondary" sx={{ marginX: (sourceImg ? -3 : 5), marginY: 1 }}>
                            {sourceImg ? <strong><ImageIcon color='primary'/> {sourceImg.name}</strong>:   'Drag and Drop' }
                        </Typography>

                    </CardContent>
                </Card>
                <Card sx={cardStyle}
                    onDrop={(event) => handleDropImage(event, 'dest')} onDragOver={handleDragOver}
                >
                    <CardContent sx={{ marginTop: 3 }}>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleFileChange(event, "dest")} onDragStart={(event) => handleDragStart(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PNG, JPG" sx={{ marginLeft: 1 }}>
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>
                        <Typography variant="subtitle1" color="textSecondary" sx={{ marginX: (destImg ? -3 : 5), marginY: 1 }}>
                            {destImg ? <strong><ImageIcon color='primary'/> {destImg.name}</strong>:   'Drag and Drop' }
                        </Typography>
                    </CardContent>
                </Card>
            </Grid>

            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />



            {highlightedSentence && (

                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <h2>Comparison Result </h2>
                    <Grid item xs={12}>
                        {/* <Button variant="outlined" onClick={handleExport(highlightedSentence?.html)} endIcon={<FileDownloadIcon />} >Export</Button> */}
                    </Grid>
                    <Grid item sx={{ margin: 2 }}>


                        <Card sx={{ width: 400 }}>
                            <CardHeader
                                title="Source Image"
                            />
                            <CardMedia
                                component="img"
                                height="250"
                                image={`data:image/png;base64,${highlightedSentence.gd_file}`}
                                alt="Source"
                            />

                        </Card>
                    </Grid>
                    <Grid item sx={{ margin: 2 }}>
                        <Card sx={{ width: 400 }}>
                            <CardHeader
                                title="Test Image"
                            />
                            <CardMedia
                                component="img"
                                height="250"
                                image={`data:image/png;base64,${highlightedSentence.cp_file}`}
                                alt="Compare"
                            />

                        </Card>
                    </Grid>
                    <Grid item sx={{ margin: 2 }}>
                        <Card sx={{ width: 400 }}>
                            <CardHeader
                                title="Output Image"
                            />
                            <CardMedia
                                component="img"
                                height="250"
                                image={`data:image/png;base64,${highlightedSentence.highlighted}`}
                                alt="Compare"
                            />

                        </Card>
                    </Grid>
                </Grid>
            )}

        </>
    )
}