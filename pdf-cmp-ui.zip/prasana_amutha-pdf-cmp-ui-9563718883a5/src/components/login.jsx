import React, { useState } from 'react';
import { makeStyles } from '@mui/styles';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { Typography } from '@mui/material';
import LoginIcon from '@mui/icons-material/Login';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import SnackbarAlert from './snack_alert';
import AuthServices from '../api/auth-services';
import { styled } from '@mui/system';

const useStyles = makeStyles((theme) => ({
    root: {
        background: 'linear-gradient(to right, #5c6bc0, #70007d)',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        background: 'linear-gradient(to left, #70007d, #512da8)',
        borderRadius: '30px',
        boxShadow: '0 5px 15px rgba(0, 0, 0, 0.15)',
        position: 'relative',
        overflow: 'hidden',
        width: "30% !important",
        minHeight: '480px',
    },
}));

const CssTextField = styled(TextField)({

    '& label.MuiFormLabel-colorPrimary': {
        color: 'white'
    },
    '& label.Mui-focused': {
        color: '#1976d2'
    },
    '& fieldset.MuiOutlinedInput-notchedOutline':{
        borderColor:"white",
    },
    '& input.MuiOutlinedInput-input':{
        color:"white"
    }
    
    
})

const ModernLogin = () => {

    const classes = useStyles();
    const [userid, setUserID] = useState(null);
    const [password, setPassword] = useState(null);
    const [severity, setSeverity] = useState(null);
    const [message, setMessage] = useState(null);

    const [open, setOpen] = useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };
    const handleLogin = async () => {
        try {

            if (!userid && !password) {
                handleClick("Please fill all the fields", "error")
                return
            }
            const jsonData = { userid: userid, password: password }

            const response = await AuthServices.login(jsonData);
            if (response) {
                localStorage.setItem('authToken', response.access_token);
                localStorage.setItem('username', response.name);
                localStorage.setItem('userid', response.id);
                handleClick(response.message, "success")
                window.location.href = '/'               
            }
        } catch (err) {
            const { data } = err || {}
            const { message } = data || {}
            if (message) {
                handleClick(message, "error")
            }
        }

    }

    return ( 
        <div className={classes.root}>
            <Container className={classes.container}>
                <Grid container>
                    <SnackbarAlert
                        severity={severity}
                        message={message}
                        open={open}
                        handleClose={handleClose}
                    />
                    <Grid item className={classes.formContainer} alignItems="center" justifyContent="center">
                        <Box alignItems="center" justifyContent="center">
                            <Button
                                variant="h6"
                                noWrap
                                component="h6"
                                href="/"
                                sx={{
                                    mr: 2,
                                    display: { xs: 'none', md: 'flex' },
                                    fontFamily: 'monospace',
                                    fontWeight: 800,
                                    letterSpacing: '.3rem',
                                    textDecoration: 'none',
                                    alignItems: "center",
                                    marginTop: 5,
                                    color: "white",
                                    fontSize: 30
                                }}
                            >
                                <CompareArrowsIcon sx={{ display: { xs: 'none', md: 'flex' }, mr: 1 }} /> ExtCmp
                            </Button>
                        </Box>
                        <Box p={3}>
                            <Typography variant="h4" color="secondary" gutterBottom>Sign In</Typography>

                            <CssTextField fullWidth label="User ID" sx={{ marginTop: 2, marginBottom: 2 }} required value={userid} onChange={(e) => setUserID(e.target.value)} />
                            <CssTextField fullWidth label="Password" type='password' sx={{ marginTop: 2 }} required value={password} onChange={(e) => setPassword(e.target.value)} />

                            <Button variant="contained" color="primary" startIcon={<LoginIcon />} sx={{ marginTop: 5 }} onClick={handleLogin}>
                                Login
                            </Button>
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </div>
    );
};

export default ModernLogin;
