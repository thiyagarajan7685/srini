import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import ImageIcon from '@mui/icons-material/Image';
import RttIcon from '@mui/icons-material/Rtt';
import ArticleIcon from '@mui/icons-material/Article';
import TextTab from './text_tab';
import ImgDocTab from './img_doc_tab';
import './menu_tab.css'

export default function LabTabs() {
  const [value, setValue] = React.useState('1');


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}
        aria-label="scrollable force tabs example" >
        <Box>
          <TabList onChange={handleChange} aria-label="lab API tabs example" variant="scrollable" indicatorColor="secondary" textColor="secondary" 
            scrollButtons
            allowScrollButtonsMobile>

            <Tab icon={<RttIcon />} iconPosition="start" label="Text" value="1"  className='tabStyle'  />
            <Tab icon={<ArticleIcon />} iconPosition="start" label="Document" value="2" className='tabStyle' />
            <Tab icon={<ImageIcon />} iconPosition="start" label="Image" value="3" className='tabStyle' />
          </TabList>
        </Box>
        <TabPanel value="1" >
          <TextTab />
        </TabPanel>
        <TabPanel value="2">
          <ImgDocTab tabs="document" />
        </TabPanel>
        <TabPanel value="3">
          <ImgDocTab tabs="image" />
        </TabPanel>
      </TabContext>
    </Box>
  );
}
