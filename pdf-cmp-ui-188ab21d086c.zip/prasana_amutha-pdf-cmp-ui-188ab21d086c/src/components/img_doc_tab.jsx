import * as React from 'react';
import { Button, Grid, Card, CardContent, Typography, CardHeader, CardMedia, Paper, Tooltip } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { Box, styled } from '@mui/system';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import DescriptionIcon from '@mui/icons-material/Description';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PdfPreview from './pdf_preview';

export default function ImgDocTab({ tabs }) {
    const [sourceImg, setSourceImg] = React.useState(null);
    const [destImg, setDestImg] = React.useState(null);

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState(null);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);
    const [highlightedtable, setHighlightedtable] = React.useState(null);
    const [columnstable, setColumnstable] = React.useState(null);
    const [dataTable, setDataTable] = React.useState(null);
    const [openLoader, setOpenLoader] = React.useState(false);

    const [Selected, setSelected] = React.useState(null);

    const [currentPage, setCurrentPage] = React.useState(1);

    const [srcTotalPages, SetSrcTotalPages] = React.useState(1);
    const [totalPages, SetTotalPages] = React.useState(1);

    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });


    const handleFileChange = (event, value) => {
        const file = event.target.files[0];
        if (file) {
            if (value === "source") {
                setSourceImg(file)
            } else if (value === "dest") {
                setDestImg(file)
            }
        }
    };

    const handleSourceFileChange = (event, value) => {
        const file = event.target.files[0];
        const fileType = file.type;
        setHighlightedtable(highlightedtable)
        if (file && isDocument(file)) {
            if (value === "source") {
                setSourceFile(file)

                setSelected((fileType === 'application/pdf') ? 'pdf_text' : 'docs_text')

            } else if (value === "dest") {
                if (Selected === null) {
                    handleClick("Select the Source file", "error")
                }
                else if (fileType !== 'application/pdf' && Selected === 'pdf_text') {
                    handleClick("Accept only PDF file", "error")
                } else if (fileType === 'application/pdf' && Selected !== 'pdf_text') {
                    handleClick("Accept only DOCX file", "error")
                }
                else {
                    setCompareFile(file)

                }

            }

        } else {
            handleClick("Accept only document file", "error")
        }
    };

    const getFileIcon = (fileType) => {
        if (fileType === 'application/pdf') {
            return <PictureAsPdfIcon color='error' />;
        } else if (fileType.startsWith('application/msword')) {
            return <DescriptionIcon color='primary' />;
        } else {
            // Default icon or handle other document types
            return <DescriptionIcon color='primary' />;
        }
    };

    const isDocument = (file) => {
        return (

            file.type === 'application/pdf' ||
            file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        );
    };

    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {


        const formData = new FormData();
        if (tabs === 'image') {
            formData.append('gd_file', sourceImg);
            formData.append('cp_file', destImg);
        } else {
            formData.append('gd_file', sourceFile);
            formData.append('cp_file', compareFile);
        }

        if ((!sourceImg && !destImg && (tabs === 'image')) || (!sourceFile && !compareFile && (tabs !== 'image'))) {
            handleClick("Please upload the Files", "error")
            return
        }
        if (!Selected && (tabs !== 'image')) {
            handleClick("Source and Test File are Differenet!", "error")
            return
        }
        setOpenLoader(true);
        try {
            let response = {}
            setHighlightedtable(highlightedtable)
            setDataTable(dataTable)
            setColumnstable(columnstable)
            setHighlightedSentence(highlightedSentence)

            if (tabs === 'image') {
                response = await AuthServices.imgCmp(formData);
            } else {
                if (Selected === 'docs_text') {
                    response = await AuthServices.docsCmp(formData);
                } else if (Selected === 'pdf_text') {
                    response = await AuthServices.pdfCmp(formData);
                } else {
                    response = await AuthServices.tableCmp(formData);
                }

            }

            if (response) {
                if (Selected === 'docs_text' || Selected === 'pdf_text' || tabs === 'image') {
                    setHighlightedSentence(response.output)
                    setCompareFile(compareFile)
                    setSourceFile(sourceFile)
                }
                else {

                    const diffData = (response.output.diff);
                    const diffValData = (response.output.diff_val);
                    const diffValColumns = (response.output.diffval_columns);
                    setHighlightedtable(diffValData)
                    setDataTable(diffData)
                    setColumnstable(diffValColumns)
                }

            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }

    function handlePreview(base64Data) {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        return url
    }

    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };
    const handleDroptest = (event) => {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        setCompareFile(file);
    };
    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            setSourceFile(file);
        }
    };
    const handleDropImage = (event, value) => {
        event.preventDefault();
        if (event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length > 0) {
            const file = event.dataTransfer.files[0];

            if (file.type.startsWith('image/')) {
                if (value === "source") {
                    setSourceImg(file);
                } else if (value === "dest") {
                    setDestImg(file);
                }
            } else {
                console.log("Please drop an image file.");
            }
        } else {
            console.log("No files dropped or dataTransfer not supported.");
        }
    };
    const handleDragStart = (event, type) => {
        event.dataTransfer.setData("text/plain", type);
    };

    const goToPreviousPage = () => {
        setCurrentPage((prevPage) => Math.max(prevPage - 1, 1)); // Ensure page number doesn't go below 1
    };

    const goToNextPage = () => {
        setCurrentPage((prevPage) => Math.min(prevPage + 1, srcTotalPages)); // Ensure page number doesn't exceed total pages
    };


    let cardStyle = { minWidth: "40%", minHeight: 350, margin: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backgroundSize: 'cover' }

    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />

            {(tabs === 'image') ?
                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <Card sx={{ ...cardStyle, backgroundImage: sourceImg ? `url("${URL.createObjectURL(sourceImg)}")` : '' }}
                        onDrop={(event) => handleDropImage(event, 'source')} onDragOver={handleDragOver}
                    >
                        <CardContent >
                            <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button' >
                                Source File
                                <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleFileChange(event, "source")} />
                            </Button>
                        </CardContent>
                    </Card>
                    <Card sx={{ ...cardStyle, backgroundImage: destImg ? `url("${URL.createObjectURL(destImg)}")` : '' }}
                        onDrop={(event) => handleDropImage(event, 'dest')} onDragOver={handleDragOver}
                    >
                        <CardContent >
                            <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                                Test file
                                <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleFileChange(event, "dest")} onDragStart={(event) => handleDragStart(event, "source")} />
                            </Button>
                        </CardContent>
                    </Card>
                </Grid>
                :

                <Grid container rowSpacing={2} alignItems="center" justifyContent="flex-start" direction="row">

                    <Grid item xs={12} md={6} >
                        <Box onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            className='drag-box'>
                            <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                                Source File
                                <VisuallyHiddenInput type="file" accept=".pdf,.doc,.docx" onChange={(event) => handleSourceFileChange(event, "source")} />
                            </Button>
                            <Tooltip title="Allowed File Types: PDF, DOCX">
                                <InfoOutlinedIcon color="disabled" fontSize="small" sx={{ marginX: "4px" }} />
                            </Tooltip>
                            {sourceFile && (
                                <Typography variant="subtitle1" color="textSecondary">
                                    {getFileIcon(sourceFile.type)}  <strong>Source Document:</strong> {sourceFile.name}
                                </Typography>
                            )}
                            {!sourceFile && (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box onDrop={handleDroptest}
                            onDragOver={handleDragOver}
                            className='drag-box'
                        >
                            <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                                Test file
                                <VisuallyHiddenInput type="file" accept=".pdf,.doc,.docx" onChange={(event) => handleSourceFileChange(event, "dest")} />
                            </Button>
                            <Tooltip title="Allowed File Types: PDF, DOCX">
                                <InfoOutlinedIcon color="disabled" fontSize="small" />
                            </Tooltip>
                            {compareFile && (
                                <Typography variant="subtitle1" color="textSecondary">
                                    {getFileIcon(compareFile.type)} <strong>Compare Document:</strong> {compareFile.name}
                                </Typography>
                            )}
                            {!compareFile && (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                        </Box>
                    </Grid>

                </Grid>

            }

            <Grid item xs={1}>
                <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
            </Grid>

            <SimpleBackdrop open={openLoader} />

            {tabs !== 'image' && highlightedSentence && (

                <div>
                    <h2>Comparison Result </h2>
                    <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center">
                        <Grid item xs={12} md={3} sm={12} >
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'  > Total Words </Typography>
                                    <Typography variant='h4' component='h4'  >  {highlightedSentence?.total_words}</Typography>
                                </CardContent>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={3} sm={6}>
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'  > Total Inserted Words </Typography>
                                    <Typography variant='h4' component='h4' color='green'  > {highlightedSentence?.insert}</Typography>
                                </CardContent>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={3} sm={6}>
                            <Paper elevation={1}>
                                <CardContent >
                                    <Typography variant='body1' component='p'> Total Deleted Words </Typography>
                                    <Typography variant='h4' component='h4' color='red'> {highlightedSentence?.delete}</Typography>
                                </CardContent>

                            </Paper>
                        </Grid>


                    </Grid>

                    <Button variant="outlined" sx={{ margin: 2 }} color='secondary' onClick={handleExport(highlightedSentence?.report)} endIcon={<FileDownloadIcon />} >Export Report</Button>
                    <Grid container spacing={2} alignItems="center" justifyContent="center">
                        <Grid item xs={12} md={12} >
                            <Button size="small" variant="contained" color='secondary' onClick={goToPreviousPage} disabled={currentPage === 1} sx={{ margin: 2 }}>Previous</Button>
                            <Button size="small" variant="contained" color='secondary' onClick={goToNextPage} disabled={currentPage === Math.max(srcTotalPages, totalPages)} sx={{ margin: 2 }}>Next</Button>
                        </Grid>
                        <Grid item xs={12} md={6} >
                            <h3>Source File</h3>
                            <PdfPreview pdf={handlePreview(highlightedSentence?.gold_base64)} currentPage={currentPage} SetTotalPages={SetSrcTotalPages} />
                        </Grid>

                        <Grid item xs={12} md={6} >
                            <h3>Output File</h3>
                            <PdfPreview pdf={handlePreview(highlightedSentence?.html)} currentPage={currentPage} SetTotalPages={SetTotalPages} />

                        </Grid>

                    </Grid>
                </div>
            )}
            {tabs !== 'image' && highlightedtable && (
                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <Grid item sx={{ margin: 2 }}>
                        <h2>Comparison Result</h2>
                        <div>
                            <table border="1">
                                <thead>
                                    <tr>
                                        {columnstable.map((column, index) => (
                                            <th key={index.id}>{column.join(' / ')}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {highlightedtable.map((record, index) => (
                                        <tr key={index.id}>
                                            {columnstable.map((column, columnIndex) => (
                                                <td key={columnIndex.id} style={{ backgroundColor: dataTable[index][`('${column[0]}', '${column[1]}')`] ? 'yellow' : 'white' }}>
                                                    {record[`('${column[0]}', '${column[1]}')`] ? record[`('${column[0]}', '${column[1]}')`] : '-'}

                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                        </div>

                    </Grid>
                </Grid>
            )}
            {tabs === 'image' && highlightedSentence && (

                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <h2>Comparison Result </h2>
                    <Grid item xs={12}>
                        <Button variant="outlined" onClick={handleExport(highlightedSentence?.html)} endIcon={<FileDownloadIcon />} >Export</Button>
                    </Grid>
                    <Grid item sx={{ margin: 2 }}>


                        <Card sx={{ maxWidth: 345 }}>
                            <CardHeader
                                title="Source Image"
                            />
                            <CardMedia
                                component="img"
                                height="194"
                                image={`data:image/png;base64,${highlightedSentence.gd_file}`}
                                alt="Paella dish"
                            />

                        </Card>
                    </Grid>
                    <Grid item sx={{ margin: 2 }}>
                        <Card sx={{ maxWidth: 345 }}>
                            <CardHeader
                                title="Compare Image"
                            />
                            <CardMedia
                                component="img"
                                height="194"
                                image={`data:image/png;base64,${highlightedSentence.cp_file}`}
                                alt="Paella dish"
                            />

                        </Card>
                    </Grid>
                </Grid>
            )}

        </>
    )
}