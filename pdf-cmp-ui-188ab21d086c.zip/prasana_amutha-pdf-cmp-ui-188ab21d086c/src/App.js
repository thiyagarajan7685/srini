import './App.css';
import Compare from './components/compare';
import ErrorPage from './components/error-page';
import Extract from './components/extract';
import Home from './components/home';
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import ModernLogin from './components/login';


const login = localStorage.getItem('authToken');

const router = createBrowserRouter([
  {
    path:    "/",
    element: ((!login) ? <ModernLogin /> :  <Home />),
    errorElement: <ErrorPage />
  },
  {
    path:  "/compare",
    element: !login ? <ModernLogin /> : <Compare />,
    errorElement: <ErrorPage />
  },
  {
    path:  "/extract",
    element: !login ? <ModernLogin /> : <Extract />,
    errorElement: <ErrorPage />
  },
]);

function App() {
  return (
    <div className="App">
        <RouterProvider router={router} />
    </div>
  );
}

export default App;
